package scripts.kt.chicken.api

import java.util.concurrent.TimeUnit

data class ScriptTask(
    val npc: Npc = Npc.CHICKENS_LUMBRIDGE_EAST,
    val stop: StopCondition = TimeStopCondition(days = Long.MAX_VALUE),
    val lootGroundItems: Boolean = false,
    val bankDisposal: Boolean = false,
    val cookThenBankDisposal: Boolean = false
) {
    override fun toString(): String {
        return "$npc $stop"
    }
}

interface Satisfiable {
    fun isSatisfied(): Boolean
}

abstract class StopCondition : Satisfiable {
    enum class ConditionType(val identity: String) {
        TIME("Time condition");
    }
}

class TimeStopCondition(
    days: Long = 0,
    hours: Long = 0,
    minutes: Long = 0,
    seconds: Long = 0
) : StopCondition() {
    private var startTime: Long = -1

    private val toMillis = TimeUnit.DAYS.toMillis(days)
        .plus(TimeUnit.HOURS.toMillis(hours))
        .plus(TimeUnit.MINUTES.toMillis(minutes))
        .plus(TimeUnit.SECONDS.toMillis(seconds))

    // true if the time has surpassed
    override fun isSatisfied(): Boolean {
        if (startTime == -1L) startTime = System.currentTimeMillis()
        return System.currentTimeMillis() - startTime >= toMillis
    }

    override fun toString(): String {
        val hours = toMillis / 1000 / 60 / 60
        val minutes = toMillis / 1000 / 60 % 60
        val seconds = toMillis / 1000 % 60
        return "until time >= (hours:$hours:minutes:$minutes:seconds:$seconds)"
    }
}

object ScriptTaskRunner : Satisfiable {
    private val taskStack: ArrayDeque<ScriptTask> = ArrayDeque()
    var activeTask: ScriptTask? = ScriptTask()

    fun execute(task: ScriptTask?) {
        // do stuff with the task
    }

    fun configure(scriptTasks: Array<ScriptTask>) {
        taskStack.clear()
        taskStack.addAll(scriptTasks)
        setNext()
    }

    fun isRunnerComplete(): Boolean = activeTask == null && taskStack.isEmpty()

    fun setNext() {
        activeTask = getNext()
    }

    private fun getNext(): ScriptTask? = taskStack.removeFirstOrNull()

    // true when the task is satisfied/done
    override fun isSatisfied(): Boolean = activeTask?.stop?.isSatisfied() == true
}