package scripts.kt.lumbridge.raider.api.behaviors.woodcutting

enum class Axe(val id: Int) {
    // TODO - more axes mapped
    BRONZE(1351)
}