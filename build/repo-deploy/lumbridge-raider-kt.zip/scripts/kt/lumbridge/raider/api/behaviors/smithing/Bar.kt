package scripts.kt.lumbridge.raider.api.behaviors.smithing

enum class Bar(
  val barSpriteId: Int,
  val barSpriteName: String
) {
    BRONZE(
        2349,
        "Bronze bar",
    )
}