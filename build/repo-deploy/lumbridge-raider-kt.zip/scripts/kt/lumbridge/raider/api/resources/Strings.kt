package scripts.kt.lumbridge.raider.api.resources

const val LUMBRIDGE_CASTLE = "Lumbridge Castle"
const val LUMBRIDGE_CASTLE_EAST = "Lumbridge Castle East"
const val LUMBRIDGE_CASTLE_WEST = "Lumbridge Castle West"

const val LUMBRIDGE_SWAMP = "Lumbridge Swamp"
const val LUMBRIDGE_SWAMP_EAST = "Lumbridge Swamp East"
const val LUMBRIDGE_SWAMP_WEST = "Lumbridge Swamp West"