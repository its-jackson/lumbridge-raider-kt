package scripts.kt.lumbridge.raider.api.resources

const val LUMBRIDGE_SWAMP_EAST = "Lumbridge Swamp East"
const val LUMBRIDGE_SWAMP_WEST = "Lumbridge Swamp West"
const val LUMBRIDGE_CASTLE = "Lumbridge Castle"