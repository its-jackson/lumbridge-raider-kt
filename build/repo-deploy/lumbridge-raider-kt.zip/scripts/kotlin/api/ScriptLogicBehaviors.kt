package scripts.kotlin.api

import org.tribot.script.sdk.Inventory
import org.tribot.script.sdk.Options
import org.tribot.script.sdk.Waiting
import org.tribot.script.sdk.antiban.Antiban
import org.tribot.script.sdk.interfaces.Positionable
import org.tribot.script.sdk.query.Query
import org.tribot.script.sdk.walking.GlobalWalking
import org.tribot.script.sdk.walking.LocalWalking
import org.tribot.script.sdk.walking.WalkState

fun canReach(p: Positionable) = LocalWalking.createMap()
    .canReach(p)

fun walkTo(entity: Positionable) = GlobalWalking.walkTo(entity) {
    if (Antiban.shouldTurnOnRun() && !Options.isRunEnabled())
        Options.setRunEnabled(true)
    WalkState.CONTINUE
}

fun lootItems() = getLootableItemsQuery()
    .toList()
    .fold(0) { runningSum, item ->
        if (Inventory.isFull())
            return runningSum

        val before = Inventory.getCount(item.id)

        if (!item.interact("Take"))
            return runningSum

        if (!Waiting.waitUntil(2500) { Inventory.getCount(item.id) > before })
            return runningSum

        val result = runningSum + item.stack
        result
    }

fun isLootableItemsFound() = getLootableItemsQuery().isAny

private fun getLootableItemsQuery(
    dist: Double = 4.5
) = Query.groundItems()
    .maxDistance(dist)
    .isReachable
