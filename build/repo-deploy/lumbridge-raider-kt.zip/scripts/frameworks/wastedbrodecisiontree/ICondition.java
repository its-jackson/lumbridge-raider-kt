package scripts.frameworks.wastedbrodecisiontree;

/**
 * @author Wastedbro
 */
public interface ICondition
{
    boolean isValid();
}
