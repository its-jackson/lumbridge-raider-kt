package scripts.frameworks.wastedbrodecisiontree;

/**
 * @author Wastedbro
 */
public interface INode
{
    INode getValidNode();

    String getStatus();

    boolean execute();
}
