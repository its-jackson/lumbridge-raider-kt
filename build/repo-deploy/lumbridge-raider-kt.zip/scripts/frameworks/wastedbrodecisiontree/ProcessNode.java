package scripts.frameworks.wastedbrodecisiontree;

/**
 * @author Wastedbro
 */
public abstract class ProcessNode implements INode
{
    @Override
    public INode getValidNode()
    {
        return this;
    }

    @Override
    public abstract String getStatus();

    @Override
    public abstract boolean execute();
}
