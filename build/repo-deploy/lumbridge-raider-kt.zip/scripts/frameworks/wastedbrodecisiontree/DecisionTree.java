package scripts.frameworks.wastedbrodecisiontree;

/**
 * @author Wastedbro
 */
public class DecisionTree
{
    INode root;

    private DecisionTree(INode root)
    {
        this.root = root;
    }

    /**
     * Construct a decision from the root node.
     *
     * @param root The root of the decision tree.
     * @return The constructed decision tree.
     */
    public static DecisionTree fromRoot(INode root)
    {
        return new DecisionTree(root);
    }

    public INode getValidNode()
    {
        return root.getValidNode();
    }
}
