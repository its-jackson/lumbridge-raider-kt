package scripts.frameworks.wastedbrodecisiontree;

/**
 * @author Wastedbro
 */
public class GenericProcessNode extends ProcessNode
{
    private String status = "";
    private IAction action;


    public GenericProcessNode(IAction action)
    {
        this.action = action;
    }
    public GenericProcessNode(IAction action, String status)
    {
        this.action = action;
        this.status = status;
    }

    @Override
    public String getStatus()
    {
        return status;
    }

    @Override
    public boolean execute()
    {
        return action.execute();
    }
}
