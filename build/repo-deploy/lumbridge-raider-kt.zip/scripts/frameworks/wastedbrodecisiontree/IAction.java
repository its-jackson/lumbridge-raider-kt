package scripts.frameworks.wastedbrodecisiontree;

/**
 * @author Wastedbro
 */
public interface IAction
{
    boolean execute();
}
