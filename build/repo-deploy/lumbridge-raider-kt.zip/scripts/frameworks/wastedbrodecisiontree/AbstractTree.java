package scripts.frameworks.wastedbrodecisiontree;

public abstract class AbstractTree {
    protected AbstractTree() {
        setupTrueFalseNodes();
    }

    protected abstract INode getRoot();

    protected abstract void setupTrueFalseNodes();
}
