package scripts.frameworks.wastedbrodecisiontree.reusablenodes.decision;

import org.tribot.script.sdk.Bank;
import scripts.frameworks.wastedbrodecisiontree.DecisionNode;

public class IsBankOpen extends DecisionNode {
    @Override
    public boolean isValid() {
        return Bank.isOpen();
    }
}
