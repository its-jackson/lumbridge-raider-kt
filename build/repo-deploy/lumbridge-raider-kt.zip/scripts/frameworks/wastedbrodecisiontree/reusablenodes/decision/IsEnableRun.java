package scripts.frameworks.wastedbrodecisiontree.reusablenodes.decision;

import org.tribot.script.sdk.Options;
import org.tribot.script.sdk.antiban.Antiban;
import scripts.frameworks.wastedbrodecisiontree.DecisionNode;

public class IsEnableRun extends DecisionNode {
    @Override
    public boolean isValid() {
        return Antiban.shouldTurnOnRun() && !Options.isRunEnabled();
    }
}
