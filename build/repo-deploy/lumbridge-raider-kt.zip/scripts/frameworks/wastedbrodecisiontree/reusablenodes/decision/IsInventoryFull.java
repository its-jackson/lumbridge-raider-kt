package scripts.frameworks.wastedbrodecisiontree.reusablenodes.decision;

import org.tribot.script.sdk.Inventory;
import scripts.frameworks.wastedbrodecisiontree.DecisionNode;

public class IsInventoryFull extends DecisionNode {
    @Override
    public boolean isValid() {
        return Inventory.isFull();
    }
}
