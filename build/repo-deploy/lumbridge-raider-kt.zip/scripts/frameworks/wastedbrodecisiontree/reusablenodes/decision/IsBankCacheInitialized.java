package scripts.frameworks.wastedbrodecisiontree.reusablenodes.decision;

import org.tribot.script.sdk.cache.BankCache;
import scripts.frameworks.wastedbrodecisiontree.DecisionNode;

public class IsBankCacheInitialized extends DecisionNode {
    @Override
    public boolean isValid() {
        return BankCache.isInitialized();
    }
}
