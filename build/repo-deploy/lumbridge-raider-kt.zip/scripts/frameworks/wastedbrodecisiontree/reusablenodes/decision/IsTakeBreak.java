package scripts.frameworks.wastedbrodecisiontree.reusablenodes.decision;

import scripts.frameworks.wastedbrodecisiontree.DecisionNode;
import scripts.models.ScriptCache;

public class IsTakeBreak extends DecisionNode {
    @Override
    public boolean isValid() {
        return ScriptCache.getInstance()
                .getBreakManager()
                .shouldTakeBreak();
    }
}
