package scripts.frameworks.wastedbrodecisiontree.reusablenodes.process;

import org.jetbrains.annotations.Nullable;
import org.tribot.script.sdk.Inventory;
import scripts.frameworks.wastedbrodecisiontree.ProcessNode;

import java.util.Optional;

public class DropItems extends ProcessNode {
    @Nullable
    private int[] itemIdsToDrop;

    public DropItems(@Nullable int... itemIdsToDrop) {
        this.itemIdsToDrop = itemIdsToDrop;
    }

    public DropItems() {
    }

    @Override
    public String getStatus() {
        return "Dropping";
    }

    @Override
    public boolean execute() {
        return Optional.ofNullable(itemIdsToDrop)
                .map(Inventory::drop)
                .map(dropped -> dropped > 0)
                .orElse(false);
    }

    @Nullable
    public int[] getItemIdsToDrop() {
        return itemIdsToDrop;
    }

    public void setItemIdsToDrop(@Nullable int... itemIdsToDrop) {
        this.itemIdsToDrop = itemIdsToDrop;
    }
}
