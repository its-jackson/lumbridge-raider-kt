package scripts.frameworks.wastedbrodecisiontree.reusablenodes.process;

import org.tribot.script.sdk.Bank;
import org.tribot.script.sdk.Waiting;
import scripts.frameworks.wastedbrodecisiontree.ProcessNode;

public class OpenBank extends ProcessNode {
    @Override
    public String getStatus() {
        return "Opening bank";
    }

    @Override
    public boolean execute() {
        return Waiting.waitUntil(Bank::ensureOpen);
    }
}
