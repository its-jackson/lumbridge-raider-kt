package scripts.frameworks.wastedbrodecisiontree.reusablenodes.process;

import org.tribot.script.sdk.Options;
import scripts.frameworks.wastedbrodecisiontree.ProcessNode;

public class EnableRun extends ProcessNode {
    @Override
    public String getStatus() {
        return "Enabling player run";
    }

    @Override
    public boolean execute() {
        return Options.setRunEnabled(true);
    }
}
