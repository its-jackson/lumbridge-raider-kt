package scripts.frameworks.wastedbrodecisiontree.reusablenodes.process;

import scripts.frameworks.wastedbrodecisiontree.ProcessNode;
import scripts.models.Logger;
import scripts.models.ScriptCache;

import java.util.Optional;

public class TakeBreak extends ProcessNode {
    @Override
    public String getStatus() {
        return ScriptCache.getInstance()
                .getBreakManager()
                .getBreakTimeString();
    }

    @Override
    public boolean execute() {
        return Optional.of(ScriptCache.getInstance().getBreakManager())
                .map(breakManager -> {
                    Logger.info(breakManager.getBreakTimeString());
                    return breakManager.takeBreak(() -> false);
                })
                .orElse(false);
    }
}
