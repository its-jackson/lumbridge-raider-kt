package scripts.frameworks.wastedbrodecisiontree.reusablenodes.process;

import org.tribot.script.sdk.Waiting;
import scripts.frameworks.wastedbrodecisiontree.ProcessNode;
import scripts.util.BankingUtils;

public class OpenDepositBox extends ProcessNode {
    @Override
    public String getStatus() {
        return "Opening deposit box";
    }

    @Override
    public boolean execute() {
        return Waiting.waitUntil(BankingUtils::clickDepositBox);
    }
}
