package scripts.frameworks.wastedbrodecisiontree.reusablenodes.process;

import scripts.frameworks.wastedbrodecisiontree.ProcessNode;
import scripts.util.PathingUtil;

public class WalkToBank extends ProcessNode {
    @Override
    public String getStatus() {
        return "Walking to bank";
    }

    @Override
    public boolean execute() {
        return PathingUtil.walkToGlobalBank();
    }
}
