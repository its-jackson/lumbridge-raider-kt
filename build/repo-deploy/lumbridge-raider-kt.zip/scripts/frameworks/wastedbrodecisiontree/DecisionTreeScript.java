package scripts.frameworks.wastedbrodecisiontree;

import lombok.val;
import org.jetbrains.annotations.NotNull;
import org.tribot.script.sdk.*;
import org.tribot.script.sdk.antiban.PlayerPreferences;
import org.tribot.script.sdk.painting.Painting;
import org.tribot.script.sdk.painting.template.basic.BasicPaintTemplate;
import org.tribot.script.sdk.script.ScriptConfig;
import org.tribot.script.sdk.script.TribotScript;
import org.tribot.script.sdk.util.TribotRandom;
import scripts.frameworks.scripting.Scriptable;
import scripts.gui.GUIFX;
import scripts.models.Logger;
import scripts.models.GainTracker;
import scripts.util.LoginHandler;

import java.util.Optional;

public abstract class DecisionTreeScript implements TribotScript, Scriptable {
    private static boolean running, printDebug;
    private static String status;

    protected final DecisionTree mainTree;

    protected GUIFX gui;
    protected BasicPaintTemplate mainPaint;
    protected GainTracker gainTracker;
    protected boolean hasArgs;

    public DecisionTreeScript() {
        this.mainTree = onDecisionTree();
    }

    public static boolean isRunning() {
        return running;
    }

    public static void setRunning(boolean running) {
        DecisionTreeScript.running = running;
    }

    public static boolean isPrintDebug() {
        return printDebug;
    }

    public static void setPrintDebug(boolean printDebug) {
        DecisionTreeScript.printDebug = printDebug;
    }

    public static String getStatus() {
        return status;
    }

    public static void setStatus(String status) {
        DecisionTreeScript.status = status;
    }

    protected abstract DecisionTree onDecisionTree();

    @Override
    public void configure(@NotNull ScriptConfig config) {
        config.setRandomsAndLoginHandlerEnabled(false);
        config.setBreakHandlerEnabled(false);
    }

    @Override
    public void execute(@NotNull String args) {
        Logger.info(String.format("Welcome %s!", Tribot.getUsername()));
        Logger.info("If you require assistance, please visit the discord server or forums thread");
        Logger.info(String.format("Discord server link: %s", DISCORD));
        onClientArguments(args);
        onListeners();
        onPaint();
        if (!LoginHandler.smartLogin()) {
            Logger.warn(String.format("%s has failed to-login, stopping script", Tribot.getUsername()));
            return;
        }
        if (!(hasArgs || onGUI())) {
            Logger.warn("GUI closed before starting, stopping script");
            return;
        }
        onLogin();
        onLoop();
    }

    @Override
    public void onLogin() {
        val zoomPreference = PlayerPreferences.preference(
                "scripts.frameworks.decisiontree.DecisionTreeScript.zoomPreference",
                generator -> generator.uniform(0.00, 40.00)
        );

        val angle = 100;

        Camera.setAngle(angle);
        Camera.setZoomPercent(zoomPreference * TribotRandom.uniform(0.1, 0.9));

        if (Options.isAcceptAidEnabled())
            Options.setAcceptAid(false);

        if (Options.isRoofsEnabled())
            Options.setRemoveRoofsEnabled(false);

        gainTracker = GainTracker.getInstance();
    }

    @Override
    public void onLoop() {
        if (mainTree == null)
            return;

        int failedAttempts = 0;

        while (running && failedAttempts < 5) {
            if (!(LoginHandler.isLoggedIn() || LoginHandler.smartLogin()))
                break;

            Optional<INode> validNode = Optional.ofNullable(mainTree.getValidNode());

            if (validNode.isPresent()) {
                INode currentNode = validNode.get();
                status = currentNode.getStatus();

                if (currentNode.execute()) {
                    if (printDebug)
                        Logger.debug(String.format("[%s] process node successful", status));
                    failedAttempts = 0;
                } else {
                    ++failedAttempts;
                    if (printDebug)
                        Logger.debug(
                                String.format(
                                        "[%s] process node unsuccessful, failed attempts: %d",
                                        status,
                                        failedAttempts
                                )
                        );
                }
            } else {
                Logger.error("Stopping script, unable to get valid node");
                running = false;
            }

            Waiting.waitUniform(40, 80);
        }
    }

    @Override
    public void onListeners() {
        ScriptListening.addEndingListener(() -> {
            Logger.info(String.format("The script has finished running. Goodbye %s!", Tribot.getUsername()));
            if (gui != null && gui.isOpen())
                gui.close();
            if (gainTracker != null)
                gainTracker.stop();
            Painting.clearPaint();
        });
    }
}
