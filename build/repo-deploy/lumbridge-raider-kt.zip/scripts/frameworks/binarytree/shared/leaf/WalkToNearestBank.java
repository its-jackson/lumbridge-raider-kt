package scripts.frameworks.binarytree.shared.leaf;

import scripts.frameworks.binarytree.api.LeafNode;
import scripts.util.PathingUtil;

public class WalkToNearestBank extends LeafNode {
    @Override
    public String getStatus() {
        return "Walking to nearest bank";
    }

    @Override
    public boolean execute() {
       return PathingUtil.findClosestBank()
                .map(PathingUtil::walkToGlobalPosition)
                .orElse(false);
    }
}
