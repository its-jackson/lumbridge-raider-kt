package scripts.frameworks.binarytree.shared.leaf;

import lombok.val;
import scripts.enumerations.BankLocation;
import scripts.frameworks.binarytree.api.LeafNode;
import scripts.models.Logger;
import scripts.models.ScriptCache;
import scripts.util.PathingUtil;

public class TravelToGrandExchange extends LeafNode {
    @Override
    public boolean execute() {
        val travelTask = ScriptCache.getInstance()
                .getGrandExchangeTeleportMethod()
                .getTravelItems();

        if (travelTask == null || travelTask.isSatisfied())
            return PathingUtil.walkTo(BankLocation.GRAND_EXCHANGE.getPosition());

        return travelTask.execute()
                .map(error -> {
                    Logger.error(error.toString());
                    ScriptCache.getInstance().getBankTaskErrorList().add(error);
                    return PathingUtil.walkTo(BankLocation.GRAND_EXCHANGE.getPosition());
                })
                .orElse(true);
    }

    @Override
    public String getStatus() {
        return "Traveling to grand exchange";
    }
}
