package scripts.frameworks.binarytree.shared.leaf;

import org.tribot.script.sdk.GrandExchange;
import org.tribot.script.sdk.tasks.Amount;
import org.tribot.script.sdk.tasks.BankTask;
import scripts.data.ItemID;
import scripts.frameworks.binarytree.api.LeafNode;
import scripts.grandexchange.GrandExchangeRestockUtil;
import scripts.grandexchange.GrandExchangeTask;
import scripts.models.Logger;
import scripts.models.ScriptCache;

import java.util.Optional;

public class GrandExchangeRestock extends LeafNode {
    @Override
    public boolean execute() {
        return Optional.of(
                        BankTask.builder()
                                .addInvItem(ItemID.COINS_995, Amount.fill(1))
                                .build()
                )
                .map(coinTask -> {
                    if (!coinTask.isSatisfied())
                        return coinTask.execute()
                                .map(coinTaskError -> {
                                    Logger.error(coinTaskError.toString());
                                    return false;
                                })
                                .orElse(true);
                    return GrandExchangeTask.builder()
                            .collectMethod(GrandExchange.CollectMethod.BANK)
                            .addItems(GrandExchangeRestockUtil.getGrandExchangeItemsNormal())
                            .addItems(GrandExchangeRestockUtil.getGrandExchangeItemRingOfWealth())
                            .addItems(GrandExchangeRestockUtil.getGrandExchangeItemGamesNecklace())
                            .build()
                            .execute()
                            .map(grandExchangeTaskError -> {
                                Logger.error(grandExchangeTaskError.toString());
                                return false;
                            })
                            .or(() -> {
                                ScriptCache.getInstance().getBankTaskErrorList().clear();
                                return Optional.of(true);
                            })
                            .orElse(false);
                })
                .orElse(false);
    }

    @Override
    public String getStatus() {
        return "Grand exchange restocking";
    }
}
