package scripts.frameworks.binarytree.shared.leaf;

import org.tribot.script.sdk.tasks.BankTask;
import scripts.frameworks.binarytree.api.LeafNode;
import scripts.models.Logger;
import scripts.models.ScriptCache;

import java.util.Optional;

public class BankRestock extends LeafNode {
    @Override
    public boolean execute() {
        return Optional.ofNullable(ScriptCache.getInstance().getBankTask())
                .flatMap(BankTask::execute)
                .map(bankTaskError -> {
                    Logger.error(bankTaskError.toString());
                    ScriptCache.getInstance().getBankTaskErrorList().add(bankTaskError);
                    return false;
                })
                .orElse(true);
    }

    @Override
    public String getStatus() {
        return "Bank restocking";
    }
}
