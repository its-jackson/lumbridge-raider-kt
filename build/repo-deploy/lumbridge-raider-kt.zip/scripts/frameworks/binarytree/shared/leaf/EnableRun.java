package scripts.frameworks.binarytree.shared.leaf;

import org.tribot.script.sdk.Options;
import scripts.frameworks.binarytree.api.LeafNode;

public class EnableRun extends LeafNode {
    @Override
    public boolean execute() {
        return Options.setRunEnabled(true);
    }

    @Override
    public String getStatus() {
        return "Enabling run";
    }
}
