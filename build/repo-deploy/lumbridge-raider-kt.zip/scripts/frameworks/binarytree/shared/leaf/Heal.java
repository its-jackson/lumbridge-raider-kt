package scripts.frameworks.binarytree.shared.leaf;

import org.jetbrains.annotations.NotNull;
import org.tribot.script.sdk.MyPlayer;
import org.tribot.script.sdk.query.Query;
import org.tribot.script.sdk.types.InventoryItem;
import scripts.antiban.AntibanExtension;
import scripts.data.foods.Cake;
import scripts.data.foods.FoodType;
import scripts.data.potions.Potion;
import scripts.frameworks.binarytree.api.LeafNode;
import scripts.util.WaitingUtils;

import java.util.Comparator;

public class Heal extends LeafNode {
    private final Comparator<InventoryItem> cakeComparator = new Cake();
    private final Comparator<InventoryItem> potionComparator = new Potion();

    @Override
    public String getStatus() {
        return "Healing";
    }

    @Override
    public boolean execute() {
        return Query.inventory()
                .actionContains("Eat", "Drink")
                .isVisible()
                .isNotNoted()
                .stream()
                .anyMatch(inventoryItem -> {
                    var foundFood = FoodType.findFood(inventoryItem.getId());
                    if (foundFood != null)
                        return foundFoodAction(foundFood);
                    return eatAction(inventoryItem);
                });
    }

    private boolean foundFoodAction(@NotNull FoodType foodType) {
        switch (foodType) {
            case CAKE: {
                return Query.inventory()
                        .idEquals(foodType.getIds())
                        .sorted(cakeComparator)
                        .findFirst()
                        .map(this::eatAction)
                        .orElse(false);
            }
            case SARADOMIN_BREW: {
                return Query.inventory()
                        .idEquals(foodType.getIds())
                        .sorted(potionComparator)
                        .findFirst()
                        .map(this::eatAction)
                        .orElse(false);
            }
            default:
                return false;
        }
    }

    private boolean eatAction(@NotNull InventoryItem foodItem) {
        int hp = MyPlayer.getCurrentHealth();
        if (!(foodItem.click() && WaitingUtils.waitUntil(1250, () -> MyPlayer.getCurrentHealth() > hp)))
            return false;
        AntibanExtension.generateEatPercent();
        return true;
    }
}
