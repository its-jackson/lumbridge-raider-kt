package scripts.frameworks.binarytree.shared.leaf;

import org.tribot.script.sdk.MyPlayer;
import org.tribot.script.sdk.query.Query;
import org.tribot.script.sdk.types.InventoryItem;
import scripts.antiban.AntibanExtension;
import scripts.data.potions.Potion;
import scripts.data.potions.PotionType;
import scripts.frameworks.binarytree.api.LeafNode;
import scripts.util.WaitingUtils;

import java.util.Comparator;

public class DrinkStaminaPotion extends LeafNode {
    private final Comparator<InventoryItem> potionComparator = new Potion();

    @Override
    public boolean execute() {
        return Query.inventory()
                .idEquals(PotionType.STAMINA.getIds())
                .stream().min(potionComparator)
                .map(pot -> {
                    int beforeEnergy = MyPlayer.getRunEnergy();
                    return pot.click() && WaitingUtils.waitUntil(1500, () -> MyPlayer.getRunEnergy() > beforeEnergy);
                })
                .map(result -> {
                    if (result)
                        AntibanExtension.generateDrinkStaminaPercent();
                    return result;
                })
                .orElse(false);
    }

    @Override
    public String getStatus() {
        return "Drinking stamina potion";
    }
}
