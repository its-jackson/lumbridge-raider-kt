package scripts.frameworks.binarytree.shared.leaf;

import scripts.frameworks.binarytree.api.LeafNode;
import scripts.models.ScriptCache;

public class TakeBreak extends LeafNode {
    @Override
    public boolean execute() {
        return ScriptCache.getInstance()
                .getBreakManager()
                .takeBreak(() -> false);
    }

    @Override
    public String getStatus() {
        return ScriptCache.getInstance()
                .getBreakManager()
                .getBreakTimeString();
    }
}
