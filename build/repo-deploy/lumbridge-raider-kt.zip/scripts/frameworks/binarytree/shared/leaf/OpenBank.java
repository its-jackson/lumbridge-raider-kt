package scripts.frameworks.binarytree.shared.leaf;

import org.tribot.script.sdk.Bank;
import scripts.frameworks.binarytree.api.LeafNode;

public class OpenBank extends LeafNode {
    @Override
    public boolean execute() {
        return Bank.ensureOpen();
    }

    @Override
    public String getStatus() {
        return "Opening bank";
    }
}
