package scripts.frameworks.binarytree.shared.tree;

import scripts.frameworks.binarytree.api.BinaryDecisionTree;
import scripts.models.stopconditions.StopCondition;

public abstract class StopConditionTree extends BinaryDecisionTree {
    private final StopCondition condition;

    public StopConditionTree(StopCondition condition) {
        this.condition = condition;
    }

    @Override
    public boolean isComplete() {
        return condition.isConditionSatisfied();
    }

    @Override
    public boolean isValid() {
        return condition != null;
    }
}
