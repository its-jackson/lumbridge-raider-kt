package scripts.frameworks.binarytree.shared.decision;

import scripts.frameworks.binarytree.api.DecisionNode;
import scripts.models.ScriptCache;

import java.util.Optional;

public class IsBankRestock extends DecisionNode {
    @Override
    public boolean isValid() {
        return Optional.ofNullable(ScriptCache.getInstance().getBankTask())
                .map(bankTask -> !bankTask.isSatisfied())
                .orElse(false);
    }
}
