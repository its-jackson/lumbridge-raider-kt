package scripts.frameworks.binarytree.shared.decision;

import scripts.frameworks.binarytree.api.DecisionNode;
import scripts.models.ScriptCache;

public class IsGrandExchangeRestock extends DecisionNode {
    @Override
    public boolean isValid() {
        return ScriptCache.getInstance().getBankTaskErrorList().size() > 0;
    }
}
