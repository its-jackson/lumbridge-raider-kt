package scripts.frameworks.binarytree.shared.decision;

import org.tribot.script.sdk.MyPlayer;
import org.tribot.script.sdk.query.Query;
import scripts.antiban.AntibanExtension;
import scripts.data.potions.PotionType;
import scripts.frameworks.binarytree.api.DecisionNode;

public class IsDrinkStaminaPotion extends DecisionNode {
    @Override
    public boolean isValid() {
        return Query.inventory().idEquals(PotionType.STAMINA.getIds()).isAny() &&
                AntibanExtension.getCurrentDrinkStaminaPercent() > MyPlayer.getRunEnergy();
    }
}
