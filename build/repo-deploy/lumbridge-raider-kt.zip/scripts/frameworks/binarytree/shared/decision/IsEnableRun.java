package scripts.frameworks.binarytree.shared.decision;

import org.tribot.script.sdk.Options;
import scripts.antiban.AntibanExtension;
import scripts.frameworks.binarytree.api.DecisionNode;

public class IsEnableRun extends DecisionNode {
    @Override
    public boolean isValid() {
        return !Options.isRunEnabled() && AntibanExtension.shouldTurnOnRun();
    }
}
