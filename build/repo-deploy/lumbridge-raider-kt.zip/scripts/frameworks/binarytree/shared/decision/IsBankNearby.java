package scripts.frameworks.binarytree.shared.decision;

import org.tribot.script.sdk.Bank;
import scripts.frameworks.binarytree.api.DecisionNode;

public class IsBankNearby extends DecisionNode {
    @Override
    public boolean isValid() {
        return Bank.isNearby();
    }
}
