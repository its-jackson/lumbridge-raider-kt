package scripts.frameworks.binarytree.shared.decision;

import org.tribot.script.sdk.MyPlayer;
import org.tribot.script.sdk.query.Query;
import scripts.antiban.AntibanExtension;
import scripts.data.foods.FoodType;
import scripts.frameworks.binarytree.api.DecisionNode;

public class IsHeal extends DecisionNode {
    @Override
    public boolean isValid() {
        return (MyPlayer.getCurrentHealthPercent() < AntibanExtension.getCurrentEatPercent()) &&
                Query.inventory()
                        .actionContains("Eat", "Drink")
                        .isVisible()
                        .isNotNoted()
                        .stream()
                        .anyMatch(inventoryItem -> {
                            if (!inventoryItem.getDefinition().getActions().contains("Drink"))
                                return true;
                            return FoodType.findFood(inventoryItem.getId()).equals(FoodType.SARADOMIN_BREW);
                        });
    }
}
