package scripts.frameworks.binarytree.shared.branch;

import scripts.frameworks.binarytree.api.BranchNode;
import scripts.frameworks.binarytree.api.DecisionNode;

public class GrandExchangeBranch extends BranchNode {

    @Override
    public void setupTrueFalseNodes() {

    }

    @Override
    public DecisionNode getRoot() {
        return null;
    }
}
