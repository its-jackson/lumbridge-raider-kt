package scripts.frameworks.binarytree.api;

public abstract class LeafNode implements Node, Actionable {
    public abstract String getStatus();

    @Override
    public Node getValidNode() {
        return this;
    }
}
