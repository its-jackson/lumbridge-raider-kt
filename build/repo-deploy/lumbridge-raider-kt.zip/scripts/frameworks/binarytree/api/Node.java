package scripts.frameworks.binarytree.api;

public interface Node {
    Node getValidNode();
}
