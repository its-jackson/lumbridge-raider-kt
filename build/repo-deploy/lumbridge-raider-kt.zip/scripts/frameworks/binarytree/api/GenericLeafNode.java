package scripts.frameworks.binarytree.api;

public class GenericLeafNode extends LeafNode {
    private final Actionable action;

    private final String status;

    public GenericLeafNode(Actionable action, String status) {
        this.action = action;
        this.status = status;
    }

    @Override
    public boolean execute() {
        return action.execute();
    }

    @Override
    public String getStatus() {
        return status;
    }
}
