package scripts.frameworks.binarytree.api;

public abstract class BranchNode extends BinaryDecisionTree {
    public BranchNode() {
    }

    public BranchNode(int maxFailedAttempts) {
        super(maxFailedAttempts);
    }

    /**
     * Branches don't have a completed state
     * @return false
     */
    @Override
    public boolean isComplete() {
        return false;
    }

    /**
     * Branches don't have a valid state
     * @return true
     */
    @Override
    public boolean isValid() {
        return true;
    }

    /**
     * Branches don't have names
     * @return ""
     */
    @Override
    public String getName() {
        return "";
    }
}
