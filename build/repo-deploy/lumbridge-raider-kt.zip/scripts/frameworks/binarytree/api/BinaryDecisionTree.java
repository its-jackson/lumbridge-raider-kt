package scripts.frameworks.binarytree.api;

public abstract class BinaryDecisionTree implements Tree, Node, Validatable {
   private final int maxFailedAttempts;

   private int failedAttempts;

   public abstract String getName();
   public abstract boolean isComplete();
   public abstract void setupTrueFalseNodes();

   public BinaryDecisionTree(int maxFailedAttempts) {
      this.maxFailedAttempts = maxFailedAttempts;
      setupTrueFalseNodes();
   }

   public BinaryDecisionTree() {
      this(5);
   }

   @Override
   public Node getValidNode() {
      return getRoot().getValidNode();
   }

   public int getMaxFailedAttempts() {
      return maxFailedAttempts;
   }

   public int getFailedAttempts() {
      return failedAttempts;
   }

   public void incrementFailedAttempts() {
      failedAttempts++;
   }

   public void resetFailedAttempts() {
      failedAttempts = 0;
   }
}
