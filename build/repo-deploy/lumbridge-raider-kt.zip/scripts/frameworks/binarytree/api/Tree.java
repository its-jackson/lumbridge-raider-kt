package scripts.frameworks.binarytree.api;

public interface Tree {
    DecisionNode getRoot();
}
