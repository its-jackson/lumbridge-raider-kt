package scripts.frameworks.binarytree.api;

public class GenericDecisionNode extends DecisionNode {
    private final Validatable validation;

    public GenericDecisionNode(Validatable validate) {
        this.validation = validate;
    }

    @Override
    public boolean isValid() {
        return validation.isValid();
    }
}
