package scripts.frameworks.binarytree.api;

public interface Validatable {
    boolean isValid();
}
