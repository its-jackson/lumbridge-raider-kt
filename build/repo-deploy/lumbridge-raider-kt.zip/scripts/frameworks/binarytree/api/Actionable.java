package scripts.frameworks.binarytree.api;

public interface Actionable {
    boolean execute();
}
