package scripts.frameworks.scripting;

import lombok.val;
import org.jetbrains.annotations.NotNull;
import org.tribot.script.sdk.*;
import org.tribot.script.sdk.antiban.PlayerPreferences;
import org.tribot.script.sdk.painting.Painting;
import org.tribot.script.sdk.painting.template.basic.BasicPaintTemplate;
import org.tribot.script.sdk.script.ScriptConfig;
import org.tribot.script.sdk.script.ScriptRuntimeInfo;
import org.tribot.script.sdk.script.TribotScript;
import org.tribot.script.sdk.util.TribotRandom;
import scripts.frameworks.binarytree.api.BinaryDecisionTree;
import scripts.gui.GUIFX;
import scripts.models.GainTracker;
import scripts.models.Logger;
import scripts.models.LootTracker;
import scripts.models.ScriptCache;
import scripts.util.LoginHandler;

import java.util.Optional;

public abstract class BinaryDecisionTreeScript implements TribotScript, Scriptable {
    @NotNull
    protected final BinaryDecisionTree tree;
    @NotNull
    protected final BinaryDecisionTreeLooper treeLooper;

    protected GUIFX gui;
    protected BasicPaintTemplate basicPaint;
    protected GainTracker gainTracker;
    protected ScriptCache scriptCache;
    protected boolean hasArgs;

    public BinaryDecisionTreeScript() {
        this.scriptCache = ScriptCache.getInstance();
        this.tree = onBinaryDecisionTree();
        this.treeLooper = new BinaryDecisionTreeLooper(this.tree);
    }

    public String getSkillStatsGained(@NotNull Skill skill) {
        return Optional.ofNullable(gainTracker)
                .map(g -> g.getSkillInfo(skill))
                .orElse("0 (0.00) (0) (+0)");
    }

    public void printLootTracker() {
        Optional.of(scriptCache.getLootTracker())
                .ifPresent(LootTracker::printSummary);
    }

    public void printBreakManager() {
        Optional.of(scriptCache.getBreakManager())
                .ifPresent(breaker -> {
                    Logger.info("~<>~ Script Stats ~<>~");
                    Logger.info(String.format("~<>~ You have taken [%d] breaks ~<>~", breaker.getCount()));
                    Logger.info(String.format("~<>~ Your last break time was [%,2f] ~<>~", breaker.getLastBreakTime()));
                    Logger.info(String.format("~<>~ Your last frequency was [%,2f] ~<>~", breaker.getLastBreakFrequency()));
                    Logger.info(String.format("~<>~ Your average break time is [%,.2f] ~<>~", breaker.getBreakTimeMean()));
                    Logger.info(String.format("~<>~ Your average frequency is [%,.2f] ~<>~", breaker.getFrequencyMean()));
                    Logger.info("~<>~ Script Stats End ~<>~");
                });
    }

    protected abstract BinaryDecisionTree onBinaryDecisionTree();

    @Override
    public void configure(@NotNull ScriptConfig config) {
        config.setRandomsAndLoginHandlerEnabled(false);
        config.setBreakHandlerEnabled(false);
    }

    @Override
    public void execute(@NotNull String args) {
        Logger.info(String.format(
                "Script name: [%s] Script version: [%s]",
                ScriptRuntimeInfo.getScriptName(),
                ScriptRuntimeInfo.getScriptRepoVersion()));
        Logger.info(String.format("Welcome %s!", Tribot.getUsername()));
        Logger.info("If you require assistance, please visit the discord server or forums thread");
        Logger.info(String.format("Discord server link: %s", DISCORD));
        onClientArguments(args);
        onListeners();
        onPaint();
        if (!LoginHandler.smartLogin()) {
            Logger.warn(String.format("%s has failed to-login, terminating", Tribot.getUsername()));
            return;
        }
        if (!(hasArgs || onGUI())) {
            Logger.warn("GUI closed before starting, terminating");
            return;
        }
        onLogin();
        onLoop();
    }

    @Override
    public void onLogin() {
        val zoomPreference = PlayerPreferences.preference(
                "scripts.frameworks.core.BinaryDecisionTreeScript.zoomPreference",
                generator -> generator.uniform(0.00, 40.00)
        );

        val angle = 100;

        Camera.setAngle(angle);
        Camera.setZoomPercent(zoomPreference * TribotRandom.uniform(0.1, 0.9));

        if (Options.isAcceptAidEnabled())
            Options.setAcceptAid(false);

        if (Options.isRoofsEnabled())
            Options.setRemoveRoofsEnabled(false);

        gainTracker = GainTracker.getInstance();
    }

    @Override
    public void onLoop() {
        treeLooper.run();
    }

    @Override
    public void onListeners() {
        ScriptListening.addEndingListener(this::onEndCleanUp);
    }

    private void onEndCleanUp() {
        Logger.info(String.format("The script has finished running. Goodbye %s!", Tribot.getUsername()));
        if (gui != null && gui.isOpen())
            gui.close();
        if (gainTracker != null)
            gainTracker.stop();
        Painting.clearPaint();
    }
}
