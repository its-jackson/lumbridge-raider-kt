package scripts.frameworks.scripting;

import org.tribot.script.sdk.painting.template.basic.PaintTextRow;

import java.awt.*;

public interface Scriptable {
    String DISCORD = "https://discord.gg/5kKq3X2X6g";

    String XP_AND_LEVEL_STRING_FORMAT = "%,d (%,.2f/hr) (%d) (+%d)";

    PaintTextRow PAINT_TEMPLATE = PaintTextRow.builder()
            .background(new Color(60, 63, 65, 222))
            .borderColor(new Color(26, 26, 26))
            .borderStroke(new BasicStroke(3))
            .font(new Font("Segoe UI", Font.PLAIN, 12))
            .textColor(Color.white)
            .build();

    PaintTextRow.PaintTextRowBuilder PAINT_TEXT_ROW_BUILDER = PaintTextRow.builder()
            .borderColor(new Color(26, 26, 26))
            .borderStroke(new BasicStroke(3))
            .font(new Font("Segoe UI", Font.PLAIN, 12))
            .textColor(Color.white);

    void onLoop();

    void onLogin();

    void onListeners();

    void onPaint();

    void onClientArguments(String arg);

    boolean onGUI();
}
