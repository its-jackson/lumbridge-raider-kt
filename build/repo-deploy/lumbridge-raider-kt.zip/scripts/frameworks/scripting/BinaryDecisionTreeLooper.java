package scripts.frameworks.scripting;

import lombok.Getter;
import lombok.Setter;
import org.tribot.script.sdk.Waiting;
import scripts.frameworks.binarytree.api.BinaryDecisionTree;
import scripts.frameworks.binarytree.api.LeafNode;
import scripts.frameworks.binarytree.api.Node;
import scripts.models.Logger;
import scripts.util.LoginHandler;

import java.util.Optional;

@Getter
@Setter
public class BinaryDecisionTreeLooper implements Runnable {
    private final BinaryDecisionTree mainTree;
    private boolean running, printDebug;
    private String status;
    private Node currentNode;

    public BinaryDecisionTreeLooper(BinaryDecisionTree mainTree) {
        this.mainTree = mainTree;
        this.running = true;
    }

    @Override
    public void run() throws IllegalStateException {
        while (running) {
            if (!mainTree.isValid()) {
                Logger.warn(String.format("[%s] is no longer valid", mainTree.getName()));
                break;
            }

            if (mainTree.isComplete()) {
                Logger.warn(String.format("[%s] is complete", mainTree.getName()));
                break;
            }

            if (mainTree.getFailedAttempts() >= mainTree.getMaxFailedAttempts()) {
                Logger.error(String.format("[%s] too many failed attempts!", mainTree.getName()));
                break;
            }

            if (!(LoginHandler.isLoggedIn() || LoginHandler.smartLogin())) {
                Logger.error("Login request has failed!");
                break;
            }

            Optional<Node> validNode = Optional.ofNullable(mainTree.getValidNode());

            if (validNode.isEmpty())
                throw new IllegalStateException("Unable to fetch valid node", new Throwable("Node unreachable."));

            currentNode = validNode.get();

            if (!(currentNode instanceof LeafNode))
                throw new IllegalStateException("Node is not leaf.", new Throwable("Incorrect configuration."));

            LeafNode leaf = (LeafNode) currentNode;

            status = leaf.getStatus();

            if (leaf.execute()) {
                if (printDebug) Logger.debug(String.format("[%s] [%s] successful", mainTree.getName(), status));
                mainTree.resetFailedAttempts();
            } else {
                mainTree.incrementFailedAttempts();
                if (printDebug) Logger.debug(String.format("[%s] [%s] unsuccessful", mainTree.getName(), status));
            }

            Waiting.waitUniform(40, 80);
        }
    }
}
