package scripts.enumerations;

public enum SpecialAttackMethod {
    SPECIAL_ORB,
    COMBAT_TAB
}
