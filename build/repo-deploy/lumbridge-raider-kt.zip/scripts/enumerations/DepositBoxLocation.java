package scripts.enumerations;

import org.tribot.script.sdk.types.WorldTile;

public enum DepositBoxLocation {

    WOODCUTTING_GUILD_AXE_SHOP(1650, 3497, 0),
    PORT_SARIM_SHIPS(3045, 3235, 0)
    ;

    final WorldTile position;

    DepositBoxLocation(int x, int y, int z) {
        this.position = new WorldTile(x, y, z);
    }

    public WorldTile getPosition() {
        return position;
    }
}
