package scripts.enumerations;

public enum InventoryDisposal {
    BANK("Bank"),
    DROP("Drop"),
    PLANK("Plank"),
    BURN("Burn"),
    FLETCH_THEN_BANK("Fletch then bank"),
    FLETCH_THEN_DROP("Fletch then drop"),
    COOK_THEN_BANK("Cook then bank"),
    COOK_THEN_DROP("Cook then drop")
    ;

    final String method;

    InventoryDisposal(String method) {
        this.method = method;
    }

    public String getMethod() {
        return method;
    }

    @Override
    public String toString() {
        return method;
    }
}
