package scripts.enumerations;

import lombok.Getter;
import org.tribot.script.sdk.types.WorldTile;

@Getter
public enum CookLocation {
    LUMBRIDGE(3231, 3196, 0),
    DRAYNOR(3100, 3257, 0),
    AL_KHARID(3272,3180, 0)
    ;

    private final WorldTile position;

    CookLocation(int x, int y, int z) {
        this.position = new WorldTile(x, y, z);
    }
}
