package scripts.enumerations;

import java.util.regex.Pattern;

public enum Regex {
    NUMERIC(Pattern.compile("[\\d.]+")),
    INTEGER(Pattern.compile("^\\d+$")),
    TILE(Pattern.compile("\\d{1,4},\\d{1,4},\\d"));

    private final Pattern pattern;

    Regex(Pattern pattern) {
        this.pattern = pattern;
    }

    public Pattern getPattern() {
        return pattern;
    }

    public static boolean isMatch(String text, Regex regex) {
        return text != null && regex.getPattern().matcher(text).matches();
    }
}
