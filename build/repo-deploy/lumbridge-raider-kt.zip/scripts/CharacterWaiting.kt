package scripts

import org.tribot.script.sdk.MyPlayer
import org.tribot.script.sdk.Waiting
import java.lang.System.currentTimeMillis
import java.util.function.BooleanSupplier

/**
 * This method will wait until the character isn't animating.
 * And it will take into account the amount of time the player has briefly stop animating.
 * You adjust the end time of which to stop if the player hasn't been animating for,
 * by default this is 1000 milliseconds.
 */
fun waitUntilNotAnimating(
    end: Long = 1000,
    step: Int = 100,
    interrupt: BooleanSupplier = BooleanSupplier { false }
): Boolean {
    var runningTime: Long = currentTimeMillis()

    while (currentTimeMillis() - runningTime < end) {
        if (interrupt.asBoolean) break
        if (MyPlayer.isAnimating()) runningTime = currentTimeMillis()
        Waiting.wait(step)
    }

    return end < currentTimeMillis() - runningTime
}