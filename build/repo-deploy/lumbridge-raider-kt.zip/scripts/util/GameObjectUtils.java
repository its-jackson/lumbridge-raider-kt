package scripts.util;

import org.tribot.script.sdk.MyPlayer;
import org.tribot.script.sdk.query.Query;
import org.tribot.script.sdk.types.Area;
import org.tribot.script.sdk.types.GameObject;

import javax.annotation.Nonnull;
import java.util.Optional;

public class GameObjectUtils {
    public static Optional<GameObject> locateGameObjectInArea(@Nonnull String name, @Nonnull Area[] areas, @Nonnull String... actions) {
        return Query.gameObjects()
                .nameContains(name)
                .actionEquals(actions)
                .inArea(areas)
                .filter(gameObject -> Query.players()
                        .filter(player -> player.isInteractingWithObject(gameObject))
                        .findFirst()
                        .isEmpty())
                .findBestInteractable()
                .or(() -> Query.gameObjects()
                        .nameEquals(name)
                        .inArea(areas)
                        .actionContains(actions)
                        .findRandom());
    }

    public static boolean isInteractingWith(@Nonnull String name) {
        return Query.gameObjects()
                .nameContains(name)
                .findFirst()
                .map(gameObject -> MyPlayer.get()
                        .map(player -> player.isInteractingWithObject(gameObject))
                        .orElse(false))
                .orElse(false);
    }
}
