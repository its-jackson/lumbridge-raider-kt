package scripts.util;

import org.tribot.script.sdk.Login;
import org.tribot.script.sdk.Waiting;
import org.tribot.script.sdk.util.Retry;

public class LoginHandler extends Login {
    public static boolean smartLogin() {
        return Retry.retry(20, () -> Waiting.waitUntil(Login::login) && Waiting.waitUntil(Login::isLoggedIn));
    }
}
