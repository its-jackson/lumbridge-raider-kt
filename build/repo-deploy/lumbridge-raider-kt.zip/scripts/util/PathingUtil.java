package scripts.util;

import org.jetbrains.annotations.NotNull;
import org.tribot.script.sdk.Bank;
import org.tribot.script.sdk.MyPlayer;
import org.tribot.script.sdk.Options;
import org.tribot.script.sdk.antiban.Antiban;
import org.tribot.script.sdk.interfaces.Positionable;
import org.tribot.script.sdk.types.Area;
import org.tribot.script.sdk.types.WorldTile;
import org.tribot.script.sdk.walking.GlobalWalking;
import org.tribot.script.sdk.walking.LocalWalking;
import org.tribot.script.sdk.walking.WalkState;

import org.tribot.script.sdk.walking.adapter.DaxWalkerAdapter;
import scripts.data.areas.GameArea;
import scripts.enumerations.BankLocation;

import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.stream.Collectors;

public class PathingUtil {
    private PathingUtil() {
        GlobalWalking.setEngine(
                new DaxWalkerAdapter(
                        "sub_JK3knXqxVGZtGR",
                        "74aa47de-1cb1-4ee1-a8c9-5bae53c70b22"
                )
        );
    }

    public static boolean walkPath(List<WorldTile> path) {
        return LocalWalking.walkPath(
                path.stream()
                        .map(tile -> (Positionable) tile)
                        .collect(Collectors.toList())
        );
    }

    public static boolean walkTo(Positionable positionable) {
        return walkTo(positionable, () -> false);
    }

    public static boolean walkTo(Positionable positionable, BooleanSupplier interrupt) {
        return isReachable(positionable) ? walkToLocalPosition(positionable, interrupt) :
                walkToGlobalPosition(positionable, interrupt);
    }

    public static boolean walkToBank() {
        return walkToBank(() -> false);
    }

    public static boolean walkToBank(BooleanSupplier interrupt) {
        return walkToLocalClosestBank(interrupt) || walkToGlobalBank(interrupt);
    }

    public static boolean walkToGlobalBank() {
        return walkToGlobalBank(() -> false);
    }

    public static boolean walkToGlobalBank(BooleanSupplier interrupt) {
        return GlobalWalking.walkToBank(() -> {
            enableRun();
            if (interrupt.getAsBoolean()) {
                return WalkState.FAILURE;
            } else if (Bank.isNearby()) {
                return WalkState.SUCCESS;
            } else {
                return WalkState.CONTINUE;
            }
        }) && WaitingUtils.waitUntilNotMoving();
    }

    public static boolean walkToGlobalPosition(Positionable positionable) {
        return walkToGlobalPosition(positionable, () -> false);
    }

    public static boolean walkToGlobalPosition(Positionable positionable, BooleanSupplier interrupt) {
        return GlobalWalking.walkTo(positionable, () -> {
            enableRun();
            if (interrupt.getAsBoolean()) {
                return WalkState.FAILURE;
            } else if (positionable.distance() < 7 && isReachable(positionable)) {
                return WalkState.SUCCESS;
            } else {
                return WalkState.CONTINUE;
            }
        }) && WaitingUtils.waitUntilNotMoving();
    }

    public static boolean walkToLocalPosition(Positionable positionable) {
        return walkToLocalPosition(positionable, () -> false);
    }

    public static boolean walkToLocalPosition(Positionable positionable, BooleanSupplier interrupt) {
        LocalWalking.Map map = LocalWalking.Map.builder()
                .travelThroughDoors(true)
                .build();
        return LocalWalking.walkPath(map.getPath(positionable), () -> {
            enableRun();
            if (interrupt.getAsBoolean()) {
                return WalkState.FAILURE;
            } else if (positionable.distance() < 7
                    && map.canReach(positionable)
                    && positionable.getTile().getPlane() == MyPlayer.getTile().getPlane()
            ) {
                return WalkState.SUCCESS;
            } else {
                return WalkState.CONTINUE;
            }
        }) && WaitingUtils.waitUntilNotMoving();
    }

    public static boolean walkToLocalClosestBank() {
        return walkToLocalClosestBank(() -> false);
    }

    public static boolean walkToLocalClosestBank(BooleanSupplier interrupt) {
        return findClosestBank().map(tile -> walkToLocalPosition(tile, interrupt))
                .orElse(false);
    }

    public static Optional<Positionable> findClosestBank() {
        Positionable[] banks = Arrays.stream(BankLocation.values())
                .map(BankLocation::getPosition)
                .toArray(Positionable[]::new);
        return Optional.ofNullable(findClosestPositionable(banks, banks.length));
    }

    public static Optional<Positionable> findClosestPositionable(Area[] areas) {
        Positionable[] positionables = Arrays.stream(areas)
                .map(Area::getAllTiles)
                .map(worldTiles -> worldTiles.stream()
                        .map(Positionable::getTile)
                        .toArray(Positionable[]::new)
                ).flatMap(Arrays::stream)
                .toArray(Positionable[]::new);
        return findClosestPositionable(positionables);
    }

    public static Optional<Positionable> findClosestPositionable(@NotNull Positionable[] positionables) {
        return Optional.ofNullable(findClosestPositionable(positionables, positionables.length));
    }

    private static Positionable findClosestPositionable(@NotNull Positionable[] positionables, int n) {
        if (n == 1) {
            return positionables[0];
        } else {
            Positionable current = positionables[n - 1];
            Positionable next = findClosestPositionable(positionables, n - 1);
            return current.distance() < next.distance() ? current : next;
        }
    }

    public static boolean isInArea(Area... areas) {
        return Arrays.stream(areas)
                .anyMatch(Area::containsMyPlayer);
    }

    public static boolean isAreaCloseBy(Area... areas) {
        return Arrays.stream(areas)
                .map(Area::getAllTiles)
                .anyMatch(worldTiles -> worldTiles.stream()
                        .anyMatch(tile -> isReachable(tile) && MyPlayer.getTile().getPlane() == tile.getPlane())
                );
    }

    public static boolean isAreaCloseBy(GameArea gameArea) {
        return isAreaCloseBy(gameArea.getArea());
    }

    public static boolean isReachable(Positionable positionable) {
        return isReachable(MyPlayer.getTile(), positionable);
    }

    public static boolean isReachable(Positionable source, Positionable positionable) {
        return LocalWalking.createMap(source).canReach(positionable);
    }

    public static boolean enableRun() {
        if (Options.isRunEnabled())
            return true;
        return Antiban.shouldTurnOnRun() && Options.setRunEnabled(true);
    }
}
