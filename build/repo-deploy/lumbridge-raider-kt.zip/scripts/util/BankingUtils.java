package scripts.util;

import org.tribot.script.sdk.Bank;
import org.tribot.script.sdk.Inventory;
import org.tribot.script.sdk.Options;
import org.tribot.script.sdk.Waiting;
import org.tribot.script.sdk.antiban.Antiban;
import org.tribot.script.sdk.antiban.PlayerPreferences;
import org.tribot.script.sdk.cache.BankCache;
import org.tribot.script.sdk.input.Keyboard;
import org.tribot.script.sdk.query.Query;
import org.tribot.script.sdk.types.InventoryItem;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class BankingUtils {
    public static final double BANK_PREFERENCE = PlayerPreferences.preference(
            BankingUtils.class.getName().concat(".BANK_PREFERENCE"),
            generator -> generator.uniform(1.0, 100.0)
    );

    public static boolean depositAllExcept(List<Integer> ids) {
        return ids != null && depositAllExcept(ids.stream().mapToInt(Integer::intValue).toArray());
    }

    public static boolean depositAllExcept(int... ids) {
        return Inventory.getAll().stream()
                .map(InventoryItem::getId)
                .distinct()
                .filter(id -> Arrays.stream(ids)
                        .allMatch(notToBank -> notToBank != id)
                )
                .collect(Collectors.toList())
                .stream()
                .allMatch(idToBank -> {
                    WaitingUtils.waitNormal(300, 55);
                    return Inventory.getCount(idToBank) == 28 ? Bank.depositInventory() : Bank.depositAll(idToBank)
                            && WaitingUtils.waitUntil(() -> !Inventory.contains(idToBank));
                });
    }

    public static boolean openDepositBox() {
        if (Bank.isDepositBoxOpen()) {
            return true;
        }
        return clickDepositBox();
    }

    public static boolean openBank() {
        if (Bank.isOpen()) {
            BankCache.update();
            return true;
        }
        return clickNonNPCBank() || clickNPCBank();
    }

    public static boolean openNPCBank() {
        if (Bank.isOpen()) {
            BankCache.update();
            return true;
        }
        return clickNPCBank();
    }

    public static boolean openNonNPCBank() {
        if (Bank.isOpen()) {
            BankCache.update();
            return true;
        }
        return clickNonNPCBank();
    }

    public static boolean openBankOrDepositBox() {
        // factorial 3
        if (BANK_PREFERENCE < 15) {
            return openDepositBox() || openNonNPCBank() || openNPCBank();
        } else if (BANK_PREFERENCE < 30) {
            return openDepositBox() || openNPCBank() || openNonNPCBank();
        } else if (BANK_PREFERENCE < 45) {
            return openNPCBank() || openNonNPCBank() || openDepositBox();
        } else if (BANK_PREFERENCE < 60) {
            return openNPCBank() || openDepositBox() || openNonNPCBank();
        } else if (BANK_PREFERENCE < 75) {
            return openNonNPCBank() || openDepositBox() || openNPCBank();
        } else {
            return openNonNPCBank() || openNPCBank() || openDepositBox();
        }
    }

    public static boolean close() {
        return Bank.isOpen() ? Bank.close() : Query.widgets()
                .actionEquals("Close")
                .findFirst()
                .map(widget -> {
                    if (Options.isEscapeClosingEnabled() && Antiban.shouldCloseWithEscape()) {
                        Keyboard.pressEscape();
                        return Bank.isDepositBoxOpen();
                    } else {
                        return widget.click("Close");
                    }
                })
                .orElse(false);
    }

    public static boolean clickDepositBox() {
        return Query.gameObjects()
                .nameContains("Bank", "Deposit")
                .actionContains("Deposit")
                .isReachable()
                .maxDistance(7)
                .findClosestByPathDistance()
                .map(gameObject -> gameObject.click() && Waiting.waitUntil(Bank::isDepositBoxOpen))
                .orElse(false);
    }

    public static boolean clickNPCBank() {
        return Query.npcs()
                .nameContains("bank", "Bank", "Banker")
                .actionContains("Bank", "Open bank", "Open")
                .isReachable()
                .maxDistance(7)
                .findClosestByPathDistance()
                .map(bank -> bank.click("Bank") && Waiting.waitUntil(Bank::isOpen))
                .orElse(false);
    }

    public static boolean clickNonNPCBank() {
        return Query.gameObjects()
                .nameContains("bank", "Bank", "Exchange", "chest")
                .actionContains("Bank", "Open bank", "Use")
                .isReachable()
                .maxDistance(7)
                .findClosestByPathDistance()
                .map(bank -> bank.click() && Waiting.waitUntil(Bank::isOpen))
                .orElse(false);
    }

}
