package scripts.util;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceDialog;
import javafx.stage.Modality;
import lombok.experimental.UtilityClass;
import org.tribot.script.sdk.Equipment;
import org.tribot.script.sdk.Tribot;
import org.tribot.script.sdk.util.ScriptSettings;
import scripts.data.interactables.InteractableEntityEquipment;
import scripts.gui.GUIFX;

import java.util.stream.Collector;

@UtilityClass
public class FXMethodProvider {
    public ObservableList<InteractableEntityEquipment> getInteractableEquipment() {
        return Equipment.getAll()
                .stream()
                .map(equipmentItem -> {
                    var actions = equipmentItem.getDefinition()
                            .getActions()
                            .stream()
                            .findFirst()
                            .orElse("");
                    var name = equipmentItem.getName();
                    var id = equipmentItem.getId();
                    var stack = equipmentItem.getStack();
                    var slot = equipmentItem.getSlot();
                    return new InteractableEntityEquipment(actions, name, id, stack, slot);
                })
                .collect(Collector.of(
                        FXCollections::observableArrayList,
                        ObservableList::add,
                        (firstList, secondList) -> {
                            firstList.addAll(secondList);
                            return firstList;
                        })
                );
    }

    public void exit(GUIFX guifx) {
        guifx.setInterruptEnd(true);
        guifx.close();
    }

    public void delete(GUIFX guifx, ScriptSettings settings) {
        var names = settings.getSaveNames();
        ChoiceDialog<String> deleteSettingsFile = new ChoiceDialog<>();
        deleteSettingsFile.initOwner(guifx.getStage());
        deleteSettingsFile.getItems().setAll(names);
        deleteSettingsFile.setTitle("Deleting");
        deleteSettingsFile.setHeaderText("Would you like to delete?");
        deleteSettingsFile.setContentText("Choose your settings file: ");
        deleteSettingsFile.showAndWait().ifPresent(file -> {
            if (!settings.delete(file)) {
                var error = new Alert(Alert.AlertType.ERROR);
                error.initOwner(guifx.getStage());
                error.setTitle("Error Deleting");
                error.setHeaderText("Couldn't Delete Settings File");
                error.setContentText("Oops, unable to delete: " + file);
                error.showAndWait();
            } else {
                Alert success = new Alert(Alert.AlertType.INFORMATION);
                success.initOwner(guifx.getStage());
                success.setTitle("Information");
                success.setHeaderText("Delete Successful! Restarting is required to take effect.");
                success.setContentText("Your settings was deleted: " + file);
                success.showAndWait();
            }
        });
    }

    public void showAndWaitAboutScript(GUIFX guifx, String scriptName) {
        var aboutAlert = new Alert(Alert.AlertType.INFORMATION);
        aboutAlert.initModality(Modality.APPLICATION_MODAL);
        aboutAlert.initOwner(guifx.getStage());
        aboutAlert.setTitle("About " + scriptName);
        aboutAlert.setHeaderText(Character.toString(169) + " Polymorphic Scripts. All rights reserved.");
        aboutAlert.setContentText("This product is licensed under TRiBot License Terms to: " + Tribot.getUsername());
        aboutAlert.showAndWait();
    }

    public void showAndWaitSaveSuccessful(GUIFX guifx) {
        Alert success = new Alert(Alert.AlertType.INFORMATION);
        success.initOwner(guifx.getStage());
        success.setTitle("Information");
        success.setHeaderText("Save Successful!");
        success.setContentText("Your settings file was saved successfully.");
        success.showAndWait();
    }

    public void showAndWaitSaveUnsuccessful(GUIFX guifx) {
        var error = new Alert(Alert.AlertType.ERROR);
        error.initOwner(guifx.getStage());
        error.setTitle("Error Saving");
        error.setHeaderText("Couldn't Save Settings File");
        error.setContentText("Oops, unable to save your settings file.");
        error.showAndWait();
    }

    public void showAndWaitLoadSuccessful(GUIFX guifx) {
        Alert success = new Alert(Alert.AlertType.INFORMATION);
        success.initOwner(guifx.getStage());
        success.setTitle("Information");
        success.setHeaderText("Load Successful!");
        success.setContentText("Your settings file was loaded correctly.");
        success.showAndWait();
    }

    public void showAndWaitLoadUnsuccessful(GUIFX guifx) {
        var error = new Alert(Alert.AlertType.ERROR);
        error.initOwner(guifx.getStage());
        error.setTitle("Error Loading");
        error.setHeaderText("Couldn't Load Settings File");
        error.setContentText("Oops, unable to load your settings file.");
        error.showAndWait();
    }
}
