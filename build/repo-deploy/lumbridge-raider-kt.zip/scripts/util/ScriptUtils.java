package scripts.util;


import org.jetbrains.annotations.NotNull;
import org.tribot.script.sdk.Skill;

import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;

public class ScriptUtils {
    public static final Random RANDOM = new Random();
    public static final double HOUR_TO_MILLIS = 3_600_000D;

    public static double getPerHour(int gained, long runtime) {
        return gained * (HOUR_TO_MILLIS / runtime);
    }

    public static double getTimeToNextLevel(Skill skill, long runtime, int gainedXp) {
        return (skill.getTotalXpToNextLevel() / getPerHour(gainedXp, runtime)) * HOUR_TO_MILLIS;
    }

    /**
     * Format the time (milliseconds) into hours/minutes/seconds
     *
     * @param millis
     * @return The formatted string of hours/minutes/seconds
     */
    public static String getTimeFormatted(long millis) {
        return String.format(
                "%02d:%02d:%02d",
                TimeUnit.MILLISECONDS.toHours(millis),
                TimeUnit.MILLISECONDS.toMinutes(millis) -
                        TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)),
                TimeUnit.MILLISECONDS.toSeconds(millis) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
    }

    /**
     * Continue to keep testing the supplier until failure.
     *
     * @param condition
     * @return True if the condition failed, otherwise false
     */
    public static boolean retryUntilFailure(BooleanSupplier condition, int maxFailures) {
        int failedAttempts = 0;
        while (failedAttempts < maxFailures) {
            if (!condition.getAsBoolean()) {
                failedAttempts++;
            } else {
                failedAttempts = 0;
                break;
            }
        }
        return failedAttempts >= maxFailures;
    }

    /**
     * Generate a random gaussian variable with indicated mean/sd,
     * such that the variable is not less than or equal to 0 and
     * not above the 32-bit maximum positive integer value (2147483647)
     *
     * @param mean
     * @param sd
     * @return The randomly generated gaussian variable with the supplied mean/sd
     */
    public static double randomSD(double mean, double sd) {
        return randomSD(Double.MIN_VALUE, Double.MAX_VALUE, mean, sd);
    }

    /**
     * Generate a random gaussian variable with the indicated mean/sd,
     * such that the variable is not less than or equal to the min and not greater than or equal to the max.
     *
     * @param min
     * @param max
     * @param mean
     * @param sd
     * @return The randomly generated gaussian variable with the supplied mean/sd
     */
    public static double randomSD(double min, double max, double mean, double sd) {
        double delay;
        do {
            delay = RANDOM.nextGaussian() * sd + mean;
        }
        while (delay <= min || delay >= max);
        return delay;
    }

    /**
     * Convert the string to an integer.
     *
     * @param text The applicable string.
     * @return The integer equivalent, otherwise -1;
     */
    @NotNull
    public static int convertToInteger(String text) {
        if (text == null)
            return -1;
        try {
            return Integer.parseInt(text);
        }
        catch (NumberFormatException exception) {
            exception.printStackTrace();
            return -1;
        }
    }

    /**
     * Convert the string to a double.
     *
     * @param text The applicable string.
     * @return The double equivalent, otherwise -1;
     */
    @NotNull
    public static double convertToDouble(String text) {
        if (text == null)
            return -1;
        try {
            return Double.parseDouble(text);
        } catch (NumberFormatException exception) {
            exception.printStackTrace();
            return -1;
        }
    }

    public static int calculateMean(List<Integer> list) {
        return (int) list.stream()
                .mapToInt(Integer::intValue)
                .average()
                .orElse(0);
    }
}
