package scripts.util;

import org.tribot.api2007.types.RSCharacter;
import org.tribot.script.sdk.MyPlayer;
import org.tribot.script.sdk.types.Player;

public class CombatUtils {
    public static boolean isInCombat() {
        return MyPlayer.get()
                .map(Player::getLegacyRSPlayer)
                .map(RSCharacter::isInCombat)
                .orElse(false);
    }
}
