package scripts.util;

import org.jetbrains.annotations.NotNull;
import org.tribot.script.sdk.MyPlayer;
import org.tribot.script.sdk.WorldHopper;
import org.tribot.script.sdk.Worlds;
import org.tribot.script.sdk.query.Query;
import org.tribot.script.sdk.types.Area;
import org.tribot.script.sdk.types.World;

import java.util.Optional;
import java.util.function.BooleanSupplier;

public class WorldHopUtils {

    public static boolean randomHop() {
        return randomHop(() -> true);
    }

    /**
     * Hop to a random world based on the number of players currently inside the radius.
     *
     * @param count  The amount of players.
     * @param radius The radius to search for.
     * @return True if the world hop was successful, otherwise false.
     */
    public static boolean randomHopPlayers(int count, int radius) {
        return randomHop(() -> Query.players()
                .inArea(Area.fromRadius(MyPlayer.getTile(), radius))
                .count() >= count);
    }

    /**
     * Hop to a random world, takes into account the current player's member status.
     *
     * @param condition The actual reason on why the player should hop worlds.
     * @return True if the world hop was successful, otherwise false.
     */
    public static boolean randomHop(@NotNull BooleanSupplier condition) {
        if (!condition.getAsBoolean()) return false;

        Optional<World> worldToHop;

        if (MyPlayer.isMember()) {
            worldToHop = Worlds.getRandomMembers();
        } else {
            worldToHop = Worlds.getRandomNonMembers();
        }

        return WaitingUtils.waitUntil(() -> worldToHop.map(world -> WorldHopper.hop(world.getWorldNumber())).orElse(false))
                && WaitingUtils.waitUntil(LoginHandler::isLoggedIn);
    }
}
