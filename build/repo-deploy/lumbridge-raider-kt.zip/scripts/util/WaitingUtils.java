package scripts.util;

import org.tribot.script.sdk.MyPlayer;

import java.util.function.BooleanSupplier;

public class WaitingUtils extends org.tribot.script.sdk.Waiting {
    public static boolean waitUntilNotAnimating(int timeout, BooleanSupplier interrupt) {
        long lastAnimationTime = System.currentTimeMillis(), waitingTime = System.currentTimeMillis();

        while ((waitingTime - lastAnimationTime) < timeout) {
            if (interrupt.getAsBoolean() || !LoginHandler.isLoggedIn())
                break;
            if (MyPlayer.isAnimating())
                lastAnimationTime = System.currentTimeMillis();
            waitingTime = System.currentTimeMillis();
            wait(100);
        }

        return (waitingTime - lastAnimationTime) >= timeout;
    }

    public static boolean waitUntilNotMoving() {
        return waitUntil(2000, MyPlayer::isMoving) && waitUntil(() -> !MyPlayer.isMoving());
    }

    public static void smallWait() {
        waitNormal(300, 45);
    }

    public static void mediumWait() {
        waitNormal(2500, 275);
    }

    public static void longWait() {
        waitNormal(5000, 450);
    }
}
