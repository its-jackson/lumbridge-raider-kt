package scripts.grandexchange;

import lombok.experimental.UtilityClass;
import org.jetbrains.annotations.NotNull;
import org.tribot.script.sdk.tasks.BankTaskError;
import org.tribot.script.sdk.types.GrandExchangeOffer;
import org.tribot.script.sdk.util.TribotRandom;
import scripts.data.ItemID;
import scripts.models.ScriptCache;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@UtilityClass
public class GrandExchangeRestockUtil {
    private final ScriptCache CACHE = ScriptCache.getInstance();

    @NotNull
    public List<Integer> getBankTaskErrorIds(@NotNull List<BankTaskError> bankTaskErrors) {
        return bankTaskErrors.stream()
                .map(error ->
                        Optional.of(error.toString())
                                .map(str ->
                                        Arrays.stream(error.toString().split(","))
                                                .filter(split -> split.matches("InsufficientItemError\\(itemId=\\d+"))
                                                .map(split -> split.substring(split.indexOf("=") + 1))
                                                .map(Integer::parseInt)
                                                .collect(Collectors.toList())
                                )
                                .orElse(Collections.emptyList())
                )
                .flatMap(List::stream)
                .collect(Collectors.toList());
    }

    @NotNull
    public List<GrandExchangeItem> getGrandExchangeItemsNormal() {
        return GrandExchangeRestockUtil.getBankTaskErrorIds(CACHE.getBankTaskErrorList())
                .stream()
                .map(GrandExchangeRestockUtil::getGrandExchangeItemWithId)
                .collect(Collectors.toList());
    }

    @NotNull
    private GrandExchangeItem getGrandExchangeItemWithId(int id) {
        if (CACHE.getFoodID() == id)
            return GrandExchangeItem.builder()
                    .itemId(id)
                    .itemQty(CACHE.getFoodAmtRestock())
                    .priceAdjustment(2)
                    .offerType(GrandExchangeOffer.Type.BUY)
                    .build();
        else if (ItemID.STAMINA_POTION4 == id)
            return GrandExchangeItem.builder()
                    .itemId(id)
                    .itemQty(CACHE.getStaminaAmtRestock())
                    .priceAdjustment(2)
                    .offerType(GrandExchangeOffer.Type.BUY)
                    .build();
        else if (ItemID.ARDOUGNE_TELEPORT == id)
            return GrandExchangeItem.builder()
                    .itemId(id)
                    .itemQty(TribotRandom.uniform(10, 100))
                    .priceAdjustment(2)
                    .offerType(GrandExchangeOffer.Type.BUY)
                    .build();
        else if (ItemID.VARROCK_TELEPORT == id)
            return GrandExchangeItem.builder()
                    .itemId(id)
                    .itemQty(TribotRandom.uniform(10, 100))
                    .priceAdjustment(2)
                    .offerType(GrandExchangeOffer.Type.BUY)
                    .build();
        else
            return GrandExchangeItem.builder()
                    .itemId(id)
                    .itemQty(1)
                    .priceAdjustment(5)
                    .offerType(GrandExchangeOffer.Type.BUY)
                    .build();
    }

    @NotNull
    public List<GrandExchangeItem> getGrandExchangeItemGamesNecklace() {
        return getGrandExchangeItemCharged("Games necklace", ItemID.GAMES_NECKLACE8, TribotRandom.uniform(1, 20));
    }

    @NotNull
    public List<GrandExchangeItem> getGrandExchangeItemRingOfWealth() {
        return getGrandExchangeItemCharged("Ring of wealth", ItemID.RING_OF_WEALTH_5, TribotRandom.uniform(1, 15));
    }

    @NotNull
    public List<GrandExchangeItem> getGrandExchangeItemCharged(String name, int id, int qty) {
        return CACHE.getBankTaskErrorList()
                .stream()
                .map(Object::toString)
                .filter(chargedItem -> chargedItem.contains(name))
                .map(necklace ->
                        GrandExchangeItem.builder()
                                .itemId(id)
                                .itemQty(qty)
                                .priceAdjustment(2)
                                .offerType(GrandExchangeOffer.Type.BUY)
                                .build()
                )
                .collect(Collectors.toList());
    }
}
