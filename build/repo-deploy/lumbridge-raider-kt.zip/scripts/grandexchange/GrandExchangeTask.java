package scripts.grandexchange;

import lombok.Builder;
import lombok.Singular;
import lombok.val;
import org.jetbrains.annotations.NotNull;
import org.tribot.script.sdk.GrandExchange;
import org.tribot.script.sdk.query.Query;
import org.tribot.script.sdk.types.GrandExchangeOffer;
import scripts.util.LoginHandler;
import scripts.util.WaitingUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

/**
 * The grand exchange task will open the primary widget, place any items to buy/sell,
 * and wait until it is complete or place a new updated offer.
 * It won't, however, open the bank to withdraw your player's coins.
 */
@Builder
public final class GrandExchangeTask {
    @NotNull
    private final LinkedList<GrandExchangeOffer> offersQueue = new LinkedList<>();

    @Singular
    @NotNull
    private List<GrandExchangeItem> addItems;

    @Builder.Default
    private GrandExchange.CollectMethod collectMethod = GrandExchange.CollectMethod.BANK;

    public Optional<GrandExchangeTaskError> execute() {
        if (!GrandExchange.isNearby())
            return Optional.of(GrandExchangeTaskError.builder()
                    .message(GrandExchangeTaskError.MESSAGE.GRAND_EXCHANGE_NOT_NEARBY)
                    .build());

        if (!(GrandExchange.isOpen() || GrandExchange.open()))
            return Optional.of(GrandExchangeTaskError.builder()
                    .message(GrandExchangeTaskError.MESSAGE.GRAND_EXCHANGE_NOT_OPEN)
                    .build());

        for (val item : addItems) {
            WaitingUtils.smallWait();

            val offer = GrandExchange.CreateOfferConfig.builder()
                    .itemId(item.getItemId())
                    .quantity(item.getItemQty())
                    .priceAdjustment(item.getPriceAdjustment())
                    .type(item.getOfferType())
                    .build();

            if (!WaitingUtils.waitUntil(() -> GrandExchange.placeOffer(offer)))
                return Optional.of(GrandExchangeTaskError.builder()
                        .queueItem(item)
                        .message(GrandExchangeTaskError.MESSAGE.GRAND_EXCHANGE_OFFER_NOT_PLACE)
                        .build());
        }

        WaitingUtils.mediumWait();

        offersQueue.addAll(getAllOffers());

        return runTask();
    }

    private Optional<GrandExchangeTaskError> runTask() {
        while (!offersQueue.isEmpty()) {
            WaitingUtils.waitUniform(80, 120);

            val peek = offersQueue.peek();

            if (peek == null) // task complete
                break;

            if (!LoginHandler.isLoggedIn())
                return Optional.of(GrandExchangeTaskError.builder()
                        .message(GrandExchangeTaskError.MESSAGE.UNKNOWN)
                        .build());

            if (!Query.grandExchangeOffers().itemIdEquals(peek.getItemId()).isAny()) { // possible the item is gone
                offersQueue.poll();
                continue;
            }

            if (WaitingUtils.waitUntil(() -> peek.getStatus().equals(GrandExchangeOffer.Status.COMPLETED))) {
                if (!WaitingUtils.waitUntil(() -> GrandExchange.collectAll(collectMethod)))
                    return Optional.of(GrandExchangeTaskError.builder()
                            .message(GrandExchangeTaskError.MESSAGE.GRAND_EXCHANGE_BANK_COLLECT_FAIL)
                            .build());
                offersQueue.poll();
                continue;
            }

            var slot = peek.getSlot();
            var id = peek.getItemId();
            var qty = peek.getTotalQuantity() - peek.getCollectableItemQuantity();
            var type = peek.getType();
            var priceAdjust = peek.getPrice() * 2;

            var updatedOffer = GrandExchange.CreateOfferConfig.builder()
                    .itemId(id)
                    .quantity(qty)
                    .price(priceAdjust)
                    .type(type)
                    .slot(slot)
                    .build();

            if (type.equals(GrandExchangeOffer.Type.BUY)) {
                if (WaitingUtils.waitUntil(() -> GrandExchange.abort(slot))) {
                    if (!WaitingUtils.waitUntil(() -> GrandExchange.placeOffer(updatedOffer)))
                        return Optional.of(
                                GrandExchangeTaskError.builder()
                                        .queueItem(
                                                GrandExchangeItem.builder()
                                                        .itemId(id)
                                                        .itemQty(qty)
                                                        .priceAdjustment(priceAdjust)
                                                        .offerType(type)
                                                        .build()
                                        )
                                        .message(GrandExchangeTaskError.MESSAGE.GRAND_EXCHANGE_OFFER_NOT_PLACE)
                                        .build()
                        );

                    var indexOfCurrentOffer = offersQueue.indexOf(peek);

                    Query.grandExchangeOffers()
                            .itemIdEquals(id)
                            .findFirst()
                            .ifPresent(found -> offersQueue.set(indexOfCurrentOffer, found));
                }
            } else {
                // todo - selling ge item, no use case right now
            }
        }
        return Optional.empty();
    }

    private List<GrandExchangeOffer> getAllOffers() {
        return Query.grandExchangeOffers()
                .itemIdEquals(
                        addItems.stream()
                                .map(GrandExchangeItem::getItemId)
                                .mapToInt(Integer::intValue)
                                .toArray()
                )
                .toList();
    }
}
