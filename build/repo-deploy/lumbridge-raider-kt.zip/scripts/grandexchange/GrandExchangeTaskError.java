package scripts.grandexchange;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Builder
public class GrandExchangeTaskError {
    private GrandExchangeItem queueItem;
    private MESSAGE message;

    @Getter
    enum MESSAGE {
        GRAND_EXCHANGE_NOT_NEARBY(),
        GRAND_EXCHANGE_NOT_OPEN(),
        GRAND_EXCHANGE_OFFER_NOT_PLACE(),
        GRAND_EXCHANGE_BANK_COLLECT_FAIL(),
        UNKNOWN()
    }
}
