package scripts.grandexchange;

import lombok.Builder;
import lombok.Data;
import org.tribot.script.sdk.types.GrandExchangeOffer;

@Builder
@Data
public class GrandExchangeItem {
    private int itemId;
    private int itemQty;
    private int priceAdjustment;
    private GrandExchangeOffer.Type offerType;
}
