package scripts

import org.tribot.script.sdk.Inventory
import org.tribot.script.sdk.Log
import org.tribot.script.sdk.Login
import org.tribot.script.sdk.Options
import org.tribot.script.sdk.antiban.Antiban
import org.tribot.script.sdk.frameworks.behaviortree.*
import org.tribot.script.sdk.painting.Painting
import org.tribot.script.sdk.painting.template.basic.BasicPaintTemplate
import org.tribot.script.sdk.painting.template.basic.PaintRows
import org.tribot.script.sdk.painting.template.basic.PaintTextRow
import org.tribot.script.sdk.script.TribotScript
import org.tribot.script.sdk.script.TribotScriptManifest
import scripts.kt.chicken.api.*

var initBehaviourTree: IBehaviorNode? = null
var logicBehaviourTree: IBehaviorNode? = null

val paintTemplate = PaintTextRow.builder()
    .noBorder()
    .build()

val mainPaint = BasicPaintTemplate.builder()
    .row(PaintRows.scriptName(paintTemplate.toBuilder()))
    .row(PaintRows.runtime(paintTemplate.toBuilder()))
    .row(paintTemplate.toBuilder().label("Task").value { ScriptTaskRunner.activeTask }.build())
    .build()

@TribotScriptManifest(
    name = "LumbridgeRaider.kt",
    author = "Polymorphic",
    category = "Combat",
    description = "Local"
)
class LumbridgeRaiderKt : TribotScript {
    init {
        val scriptTasks = arrayOf(
            ScriptTask(
                stop = TimeStopCondition(minutes = 10, hours = 2, seconds = 45),
                cookThenBankDisposal = true,
                lootGroundItems = true
            )
        )
        ScriptTaskRunner.configure(scriptTasks)
    }

    init {
        Painting.addPaint(mainPaint::render)
    }

    // this behaviour tree ensures the user is logged in first
    // then it will ensure the inventory is empty
    // before entering the main script logic
    init {
        initBehaviourTree = behaviorTree {
            sequence {
                selector {
                    inverter { condition { !Login.isLoggedIn() } }
                    repeatUntil({ Login.isLoggedIn() }) { condition { Login.login() } }
                }
                selector {
                    inverter { condition { !Inventory.isEmpty() } }
                    repeatUntil({ Inventory.isEmpty() }) { walkToAndDepositBank() }
                }
            }
        }
    }

    // this behaviour tree is the main logic for the script
    // it will log in if the user is logged out,
    // enable running, set the next task, do banking,
    // do cooking, do fighting, and do looting
    init {
        logicBehaviourTree = behaviorTree {
            repeatUntil({ ScriptTaskRunner.isRunnerComplete() }) {
                selector {
                    // terminate
                    sequence {
                        condition { ScriptTaskRunner.isRunnerComplete() }
                        sequence { BehaviorTreeStatus.KILL }
                    }

                    sequence {
                        // character login
                        selector { repeatUntil({ Login.isLoggedIn() }) { condition { Login.login() } } }

                        // character running
                        selector {
                            condition { !Antiban.shouldTurnOnRun() || Options.isRunEnabled() }
                            condition { Options.setRunEnabled(true) }
                        }

                        // script task runner
                        selector {
                            inverter {
                                condition { ScriptTaskRunner.isSatisfied() }
                            }
                            sequence {
                                walkToAndDepositBank()
                                perform { ScriptTaskRunner.setNext() }
                            }
                        }

                        // character cooking
                        selector {
                            inverter { condition { isCookRawFood(ScriptTaskRunner.activeTask) } }
                            repeatUntil({ !isCookRawFood(ScriptTaskRunner.activeTask) }) {
                                walkToAndCookRange()
                            }
                        }

                        // character banking
                        selector {
                            inverter {
                                condition { isBankNeeded(ScriptTaskRunner.activeTask) }
                            }
                            walkToAndDepositBank()
                        }

                        // character combat
                        selector {
                            condition { isCombat(ScriptTaskRunner.activeTask) }
                            walkToAndAttackNpc(ScriptTaskRunner.activeTask)
                        }

                        // character looting
                        selector {
                            repeatUntil({ !foundLootableItems(ScriptTaskRunner.activeTask) || Inventory.isFull() }) {
                                sequence {
                                    condition { lootItems(ScriptTaskRunner.activeTask) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun execute(args: String) {
        val initState = initBehaviourTree?.tick()
        Log.debug("Initialize ${initBehaviourTree?.name} ?: [$initState]")
        if (initState != BehaviorTreeStatus.SUCCESS) return

        val logicState = logicBehaviourTree?.tick()
        Log.debug("LumbridgeRaider.kt ${logicBehaviourTree?.name} ?: [$logicState]")
    }
}