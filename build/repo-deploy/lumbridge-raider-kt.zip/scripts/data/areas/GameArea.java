package scripts.data.areas;

import org.tribot.script.sdk.interfaces.Positionable;
import org.tribot.script.sdk.types.Area;

import java.util.Arrays;
import java.util.Objects;

public class GameArea extends BaseGameArea {
    protected Area[] area;
    protected String name;

    public GameArea(Area[] areas, String name) {
        this.area = areas;
        this.name = name;
    }

    public GameArea(String name, Area... areas) {
        this.name = name;
        this.area = areas;
    }

    public GameArea(String name, int radius, Positionable centerTile) {
        this.name = name;
        this.area = new Area[]{Area.fromRadius(centerTile.getTile(), radius)};
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public Area[] getArea() {
        return this.area;
    }

    @Override
    public void setArea(Area[] area) {
        this.area = area;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GameArea gameArea = (GameArea) o;
        return Arrays.equals(area, gameArea.area) && Objects.equals(name, gameArea.name);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(name);
        result = 31 * result + Arrays.hashCode(area);
        return result;
    }

    @Override
    public String toString() {
        return "GameArea{" +
                "area=" + Arrays.toString(area) +
                ", name='" + name + '\'' +
                '}';
    }
}
