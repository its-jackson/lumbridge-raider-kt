package scripts.data.areas;

import org.tribot.script.sdk.types.Area;

public abstract class BaseGameArea {
    public abstract String getName();
    public abstract void setName(String name);
    public abstract Area[] getArea();
    public abstract void setArea(Area[] area);

    @Override
    public String toString() {
        return getName();
    }
}
