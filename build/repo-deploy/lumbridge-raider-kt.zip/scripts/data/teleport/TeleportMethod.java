package scripts.data.teleport;

import lombok.Getter;
import org.jetbrains.annotations.Nullable;
import org.tribot.script.sdk.Equipment;
import org.tribot.script.sdk.tasks.Amount;
import org.tribot.script.sdk.tasks.BankTask;
import org.tribot.script.sdk.tasks.EquipmentReq;
import scripts.data.ItemID;

@Getter
public enum TeleportMethod {
    ROYAL_SEED_POD(
            BankTask.builder()
                    .addInvItem(ItemID.ROYAL_SEED_POD, Amount.of(1))
                    .build()
    ),
    SLAYER_RING_GNOME_STRONGHOLD(
            BankTask.builder()
                    .addEquipmentItem(
                            EquipmentReq.slot(Equipment.Slot.RING)
                                    .chargedItem("Slayer ring", 1)
                    )
                    .build()
    ),
    RING_OF_WEALTH(
            BankTask.builder()
                    .addEquipmentItem(
                            EquipmentReq.slot(Equipment.Slot.RING)
                                    .chargedItem("Ring of wealth", 1)
                    )
                    .build()
    ),
    VARROCK_TAB(
            BankTask.builder()
                    .addInvItem(ItemID.VARROCK_TELEPORT, Amount.fill(1))
                    .build()
    ),
    ARDOUGNE_TAB(
            BankTask.builder()
                    .addInvItem(ItemID.ARDOUGNE_TELEPORT, Amount.fill(1))
                    .build()
    ),
    DEFAULT(null);

    @Nullable
    private final BankTask travelItems;

    TeleportMethod(@Nullable BankTask travelItems) {
        this.travelItems = travelItems;
    }
}
