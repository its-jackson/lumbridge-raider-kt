package scripts.data.interactables;

import org.tribot.script.sdk.Equipment;

import java.util.Arrays;
import java.util.Objects;

public class InteractableEntityEquipment extends InteractableEntityItem {
    private final Equipment.Slot slot;

    public InteractableEntityEquipment(String action, String name, int id, int quantity, Equipment.Slot slot) {
        super(action, name, id, quantity);
        this.slot = slot;
    }

    public InteractableEntityEquipment(String name, String action, int numberIds, int quantity, Equipment.Slot slot, int... ids) {
        super(name, action, numberIds, quantity, ids);
        this.slot = slot;
    }


    public Equipment.Slot getSlot() {
        return slot;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        InteractableEntityEquipment that = (InteractableEntityEquipment) o;
        return slot == that.slot;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), slot);
    }

    @Override
    public String toString() {
        return "{" +
                "slot=" + slot +
                ", action='" + action + '\'' +
                ", name='" + name + '\'' +
                ", qty='" + getQuantity() + '\'' +
                ", ids=" + Arrays.toString(ids) +
                '}';
    }
}
