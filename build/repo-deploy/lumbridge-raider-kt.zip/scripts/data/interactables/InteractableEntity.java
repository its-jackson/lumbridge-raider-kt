package scripts.data.interactables;

import com.allatori.annotations.DoNotRename;

import java.util.Arrays;
import java.util.Objects;

/**
 * @author fluffee
 */
@DoNotRename
public class InteractableEntity extends BaseInteractableEntity {
    @DoNotRename
    protected String action, name;
    @DoNotRename
    protected int numberFoundIds, numberIds;
    @DoNotRename
    protected int[] ids;

    /**
     * Constructor for an interactable object that has a single id
     *
     * @param name   Name of object
     * @param action Action to use with the object (i.e. Wield, Wear, etc.)
     * @param id     ID of the object that we know starting off.
     */
    public InteractableEntity(String action, String name, int id) {
        this.action = action;
        this.name = name;
        this.ids = new int[]{id};
    }

    /**
     * Create an interactable object with multiple ids.
     *
     * @param name      Name of object
     * @param numberIds Number of possible IDs the object can have. This is necessary to allow the interactable to know
     *                  when to stop searching.
     * @param action    Action to use with the object (i.e. Wield, Wear, etc.)
     * @param ids       IDs of the object that we know starting off.
     */
    public InteractableEntity(String name, String action, int numberIds, int... ids) {
        this.name = name;
        this.action = action;
        this.numberIds = numberIds;
        this.numberFoundIds = ids.length;

        if (this.numberIds != this.numberFoundIds) {
            this.ids = new int[this.numberIds];
            for (int i = this.numberFoundIds; i < this.numberIds; i++) {
                this.ids[i] = DEFAULT_ID;
            }
        } else {
            this.ids = ids;
        }
    }

    public String getAction() {
        return this.action;
    }

    public int getNumberIds() {
        return this.numberIds;
    }

    public int[] getInteractableIds() {
        return this.ids;
    }

    /**
     * Return the first id cached for this interactable
     *
     * @return int containing the id
     */
    @Override
    public int getId() {
        return this.ids[0];
    }

    /**
     * Gets a specific ID from the stored ID array
     *
     * @param index index of the id to grab, indices start at 0.
     * @return int containing the specified id.
     */
    public int getId(int index) {
        return this.ids[index];
    }

    @Override
    public void setId(int id) {
        if (this.ids.length < this.numberFoundIds) {
            this.ids[this.numberFoundIds++] = id;
        }
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean isAllIdsFound() {
        return this.numberFoundIds == this.ids.length;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InteractableEntity that = (InteractableEntity) o;
        return numberFoundIds == that.numberFoundIds
                && numberIds == that.numberIds
                && Objects.equals(action, that.action)
                && Objects.equals(name, that.name)
                && Arrays.equals(ids, that.ids);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(action, name, numberFoundIds, numberIds);
        result = 31 * result + Arrays.hashCode(ids);
        return result;
    }

    @Override
    public String toString() {
        return "InteractableEntity{" +
                "action='" + action + '\'' +
                ", name='" + name + '\'' +
                ", numberFoundIds=" + numberFoundIds +
                ", numberIds=" + numberIds +
                ", ids=" + Arrays.toString(ids) +
                '}';
    }
}
