package scripts.data.interactables;

import com.allatori.annotations.DoNotRename;
import org.tribot.script.sdk.MyPlayer;
import org.tribot.script.sdk.Skill;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@DoNotRename
public class Stats {
    @DoNotRename
    private final HashMap<Skill, Integer> skillLevelsRequired;
    @DoNotRename
    private final boolean member;

    public Stats(Map<Skill, Integer> mappedSkillLevels, boolean member) {
        this.skillLevelsRequired = new HashMap<>();
        this.member = member;

        if (mappedSkillLevels != null)
            this.skillLevelsRequired.putAll(mappedSkillLevels);
    }

    public boolean allSkillLevelsSatisfied() {
       return skillLevelsRequired.entrySet()
               .stream()
               .allMatch(entry -> {
                   Skill skill = entry.getKey();
                   int levelRequired = entry.getValue();
                   return skill.getActualLevel() >= levelRequired;
               });
    }

    public boolean isMembershipAndAllSkillLevelsSatisfied() {
        return member ? MyPlayer.isMember() && allSkillLevelsSatisfied() : allSkillLevelsSatisfied();
    }

    public boolean isMembershipSatisfied() {
        return !member || MyPlayer.isMember();
    }

    public HashMap<Skill, Integer> getSkillLevelsRequired() {
        return skillLevelsRequired;
    }

    public boolean isMember() {
        return member;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Stats stats = (Stats) o;
        return member == stats.member && Objects.equals(skillLevelsRequired, stats.skillLevelsRequired);
    }

    @Override
    public int hashCode() {
        return Objects.hash(skillLevelsRequired, member);
    }

    @Override
    public String toString() {
        return "Stats{" +
                "skillLevelsRequired=" + skillLevelsRequired +
                ", member=" + member +
                '}';
    }
}
