package scripts.data.interactables;

import com.allatori.annotations.DoNotRename;

import java.util.Arrays;
import java.util.Objects;

@DoNotRename
public class InteractableEntityStats extends InteractableEntity {
    @DoNotRename
    private final Stats stats;

    public InteractableEntityStats(String action, String name, int id, Stats stats) {
        super(action, name, id);
        this.stats = stats;
    }

    public InteractableEntityStats(String name, String action, int numberIds, Stats stats, int... ids) {
        super(name, action, numberIds, ids);
        this.stats = stats;
    }

    public Stats getStats() {
        return stats;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        InteractableEntityStats that = (InteractableEntityStats) o;
        return Objects.equals(stats, that.stats);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), stats);
    }

    @Override
    public String toString() {
        return "InteractableStats{" +
                "stats=" + stats +
                ", action='" + action + '\'' +
                ", name='" + name + '\'' +
                ", numberFoundIds=" + numberFoundIds +
                ", numberIds=" + numberIds +
                ", ids=" + Arrays.toString(ids) +
                '}';
    }
}
