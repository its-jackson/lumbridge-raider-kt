package scripts.data.interactables;

import com.allatori.annotations.DoNotRename;

import java.util.Arrays;
import java.util.Objects;

@DoNotRename
public class InteractableEntityItemStats extends InteractableEntityItem {
    @DoNotRename
    protected Stats stats;

    public InteractableEntityItemStats(String action, String name, int id, int quantity, Stats stats) {
        super(action, name, id, quantity);
        this.stats = stats;
    }

    public InteractableEntityItemStats(String name, String action, int numberIds, int quantity, Stats stats, int... ids) {
        super(name, action, numberIds, quantity, ids);
        this.stats = stats;
    }

    public Stats getStats() {
        return stats;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        InteractableEntityItemStats that = (InteractableEntityItemStats) o;
        return Objects.equals(stats, that.stats);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), stats);
    }

    @Override
    public String toString() {
        return "InteractableEntityItemStats{" +
                "stats=" + stats +
                ", quantity=" + getQuantity() +
                ", action='" + action + '\'' +
                ", name='" + name + '\'' +
                ", numberFoundIds=" + numberFoundIds +
                ", numberIds=" + numberIds +
                ", ids=" + Arrays.toString(ids) +
                '}';
    }
}
