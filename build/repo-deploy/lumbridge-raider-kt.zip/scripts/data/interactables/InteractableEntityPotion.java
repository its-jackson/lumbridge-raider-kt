package scripts.data.interactables;

import java.util.Arrays;

public class InteractableEntityPotion extends InteractableEntityItem {
    private static final String POTION_ACTION = "Drink";
    private final InteractableEntity[] potions;
    private final int defaultDose;

    public InteractableEntityPotion(String potionName, int id, int quantity) {
        super(POTION_ACTION, potionName, id, quantity);
        this.defaultDose = 4;
        this.potions = setupPotions(this.defaultDose);
    }

    private InteractableEntity[] setupPotions(int size) {
        InteractableEntity[] potions = new InteractableEntity[size];
        for (int i = 0; i < size; i++) {
            potions[i] = new InteractableEntity(this.action, this.name + " (" + (i + 1) + ")", this.getId());
        }
        return potions;
    }

    public String getPotionAction() {
        return POTION_ACTION;
    }

    public int getDefaultDose() {
        return this.defaultDose;
    }

    public InteractableEntity[] getPotions() {
        return this.potions;
    }

    public InteractableEntity getWithdrawPotion() {
        return this.potions[this.potions.length-1];
    }

    public InteractableEntity getPotion(int dose) {
        return potions[dose-1];
    }

    public int[] getAllPotionIds() {
        return Arrays.stream(potions).mapToInt(InteractableEntity::getId).toArray();
    }

    public String[] getAllPotionNames() {
        return Arrays.stream(potions).map(InteractableEntity::getName).toArray(String[]::new);
    }

    public String getPotionName() {
        return this.getPotionName(this.defaultDose);
    }

    public String getPotionName(int potionDose) {
        return getPotion(potionDose).getName();
    }
}
