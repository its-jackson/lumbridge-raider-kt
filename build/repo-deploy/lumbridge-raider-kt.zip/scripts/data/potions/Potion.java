package scripts.data.potions;

import org.tribot.script.sdk.types.InventoryItem;

import java.util.Comparator;

public class Potion implements Comparator<InventoryItem> {
    /**
     * @param o1 the first object to be compared.
     * @param o2 the second object to be compared.
     * @return The potion dose compared, uses Integer.compareUnsigned().
     * negative if less than, positive if greater than, zero if equal
     */
    @Override
    public int compare(InventoryItem o1, InventoryItem o2) {
        String name1 = o1.getName();
        String name2 = o2.getName();
        int length1 = name1.length();
        int length2 = name2.length();
        String dose1 = name1.substring(length1 - 2, length1 - 1);
        String dose2 = name2.substring(length2 - 2, length2 - 1);
        return Integer.compareUnsigned(Integer.parseInt(dose1), Integer.parseInt(dose2));
    }
}
