package scripts.data.potions;

import com.google.common.collect.ImmutableMap;
import lombok.Getter;
import scripts.data.ItemID;

import java.util.Map;

@Getter
public enum PotionType {
    STAMINA(
            "Stamina potion",
            ItemID.STAMINA_POTION4,
            ItemID.STAMINA_POTION3,
            ItemID.STAMINA_POTION2,
            ItemID.STAMINA_POTION1
    );

    private static final Map<Integer, PotionType> POTIONS;

    static {
        var builder = new ImmutableMap.Builder<Integer, PotionType>();

        for (PotionType potionType : PotionType.values()) {
            for (int id : potionType.getIds()) {
                builder.put(id, potionType);
            }
        }

        POTIONS = builder.build();
    }

    private final String name;
    private final int[] ids;

    PotionType(String name, int... ids) {
        this.name = name;
        this.ids = ids;
    }

    public static PotionType findPotion(int id) {
        return POTIONS.get(id);
    }
}
