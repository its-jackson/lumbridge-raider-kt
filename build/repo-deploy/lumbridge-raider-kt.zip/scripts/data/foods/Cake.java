package scripts.data.foods;

import org.tribot.script.sdk.types.InventoryItem;

import java.util.Comparator;

public final class Cake implements Comparator<InventoryItem> {
    private static final String SLICE = "Slice";
    private static final String TWO_THIRD = "2/3";
    private static final String WHOLE = "Cake";

    /**
     * @param o1 the first object to be compared.
     * @param o2 the second object to be compared.
     * @return slice < 2/3 < cake ; negative if less than, positive if greater than, zero if equal
     */
    @Override
    public int compare(InventoryItem o1, InventoryItem o2) {
        var name1 = o1.getName();
        var name2 = o2.getName();

        if (name1.contains(SLICE) && name2.contains(TWO_THIRD)) {
            return -1;
        } else if (name1.contains(SLICE) && name2.contains(WHOLE)) {
            return -1;
        } else if (name1.contains(SLICE) && name2.contains(SLICE)) {
            return 0;
        } else if (name1.contains(TWO_THIRD) && name2.contains(SLICE)) {
            return 1;
        } else if (name1.contains(TWO_THIRD) && name2.contains(WHOLE)) {
            return -1;
        } else if (name1.contains(TWO_THIRD) && name2.contains(TWO_THIRD)) {
            return 0;
        } else if (name1.contains(WHOLE) && name2.contains(SLICE)) {
            return 1;
        } else if (name1.contains(WHOLE) && name2.contains(TWO_THIRD)) {
            return 1;
        } else {
            return 0;
        }
    }
}
