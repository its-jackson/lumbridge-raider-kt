package scripts.data.foods;

import com.google.common.collect.ImmutableMap;
import lombok.Getter;
import scripts.data.ItemID;

import java.util.Map;

@Getter
public enum FoodType {
    CAKE(
            "Cake",
            ItemID.CAKE,
            ItemID.SLICE_OF_CAKE,
            ItemID._23_CAKE
    ),
    SARADOMIN_BREW(
            "Saradomin brew",
            ItemID.SARADOMIN_BREW4,
            ItemID.SARADOMIN_BREW2,
            ItemID.SARADOMIN_BREW3,
            ItemID.SARADOMIN_BREW1
    );

    private static final Map<Integer, FoodType> FOODS;

    static {
        var builder = new ImmutableMap.Builder<Integer, FoodType>();

        for (FoodType foodType : FoodType.values()) {
            for (int id : foodType.getIds()) {
                builder.put(id, foodType);
            }
        }

        FOODS = builder.build();
    }

    private final String name;
    private final int[] ids;

    FoodType(String foodName, int... foodItemIds) {
        this.name = foodName;
        this.ids = foodItemIds;
    }

    public static FoodType findFood(int id) {
        return FOODS.get(id);
    }
}
