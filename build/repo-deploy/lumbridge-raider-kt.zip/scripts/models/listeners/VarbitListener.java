package scripts.models.listeners;

import scripts.data.Varbits;

public interface VarbitListener {

    void onVarbitChange(Varbits varbit, Integer value);
}
