package scripts.models.listeners;

import org.tribot.script.sdk.Bank;
import org.tribot.script.sdk.Inventory;
import org.tribot.script.sdk.Login;
import org.tribot.script.sdk.Waiting;
import org.tribot.script.sdk.types.InventoryItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.function.BooleanSupplier;

/**
 * @author daxmagex - adapted by polymorphic
 */
public class InventoryObserver extends Thread
{
    public static final BooleanSupplier DEFAULT_CONDITION = () -> !Bank.isOpen();

    private final ArrayList<InventoryListener> listeners;
    private final BooleanSupplier condition;

    private boolean shouldStop = false;

    public InventoryObserver(BooleanSupplier condition)
    {
        this.listeners = new ArrayList<>();
        this.condition = condition;
    }

    public InventoryObserver() {
        this(DEFAULT_CONDITION);
    }

    @Override
    public void run()
    {
        while (!Login.isLoggedIn())
        {
            Waiting.waitUniform(400, 500);
        }

        HashMap<Integer, Integer> map = inventoryHashMap();

        while (true)
        {
            if(shouldStop) break;

            Waiting.wait(100);

            if (!Login.isLoggedIn()) continue;

            if (!condition.getAsBoolean())
            {
                map = inventoryHashMap();
                continue;
            }

            HashMap<Integer, Integer> updatedMap = inventoryHashMap();

            for (Integer i : updatedMap.keySet())
            {
                int countInitial = map.getOrDefault(i, 0);
                int countFinal = updatedMap.get(i);

                if (countFinal > countInitial)
                {
                    addTrigger(i, countFinal - countInitial);
                }
                else if (countFinal < countInitial)
                {
                    subtractedTrigger(i, countInitial - countFinal);
                }

                map.remove(i);
            }

            for (Integer i : map.keySet())
                if (!updatedMap.containsKey(i))
                    subtractedTrigger(i, map.get(i));

            map = updatedMap;
        }
    }

    public HashMap<Integer, Integer> inventoryHashMap()
    {
        HashMap<Integer, Integer> map = new HashMap<>();

        for (InventoryItem item : Inventory.getAll())
            map.put(item.getId(), Inventory.getCount(item.getId()));

        return map;
    }

    public void addListener(InventoryListener inventoryListener)
    {
        listeners.add(inventoryListener);
    }

    public void addTrigger(int id, int count)
    {
        for (InventoryListener listener : listeners)
            listener.inventoryItemGained(id, count);
    }

    public void subtractedTrigger(int id, int count)
    {
        for (InventoryListener listener : listeners)
            listener.inventoryItemLost(id, count);
    }

    public void setShouldStop(boolean shouldStop)
    {
        this.shouldStop = shouldStop;
    }
}