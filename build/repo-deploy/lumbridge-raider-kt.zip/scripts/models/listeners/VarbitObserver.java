package scripts.models.listeners;

import org.tribot.script.sdk.GameState;
import org.tribot.script.sdk.Login;
import org.tribot.script.sdk.Waiting;
import scripts.data.Varbits;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;

public class VarbitObserver extends Thread {

    private final Set<VarbitListener> observables;
    private final Set<Varbits> varbits;
    private final Supplier<Boolean> shouldNotify;

    private final Map<Varbits, Integer> varBitValues;

    public VarbitObserver(Supplier<Boolean> shouldNotify, Varbits varbit, VarbitListener observable) {
        this.observables = new HashSet<>();
        this.varbits = new HashSet<>();
        this.varBitValues = new HashMap<>();
        this.shouldNotify = shouldNotify;

        this.varbits.add(varbit);
        this.observables.add(observable);
    }

    @Override
    public void run() {
        while (!Login.isLoggedIn()) {
            Waiting.wait(500);
        }

        while (true) {
            Waiting.wait(100);

            if (!Login.isLoggedIn())
                continue;

            varbits.forEach(varBit -> {
                int currentValue = GameState.getVarbit(varBit.getId());
                if (shouldNotify.get() && varBitValues.getOrDefault(varBit, -99) != currentValue) {
                    observables.forEach(observable -> observable.onVarbitChange(varBit, currentValue));
                }
                varBitValues.put(varBit, currentValue);
            });
        }
    }

    public void addVarbit(Varbits rsVarBit) {
        varbits.add(rsVarBit);
    }

    public void addObservable(VarbitListener varBitListener) {
        observables.add(varBitListener);
    }
}
