package scripts.models;

import lombok.Getter;
import org.jetbrains.annotations.NotNull;
import org.tribot.script.sdk.Inventory;
import org.tribot.script.sdk.pricing.Pricing;
import org.tribot.script.sdk.types.InventoryItem;

import java.util.HashMap;

public final class LootTracker
{
    private final long startTime;

    @NotNull
    private final HashMap<String, Integer> looted;

    @NotNull
    private final HashMap<Integer, Integer> gold;

    @NotNull
    private HashMap<InventoryItem, Integer> beforeLoot;
    @NotNull
    private HashMap<InventoryItem, Integer> afterLoot;

    @Getter
    private int goldGained = 0;

    public LootTracker()
    {
        this.startTime = System.currentTimeMillis();
        this.looted = new HashMap<>();
        this.gold = new HashMap<>();
        this.beforeLoot = new HashMap<>();
        this.afterLoot = new HashMap<>();
    }

    public void preTrigger()
    {
        beforeLoot = getMap();
    }

    public void postTrigger()
    {
        afterLoot = getMap();
        afterLoot.forEach((item, amount) ->
        {
            if (!beforeLoot.containsKey(item) || (beforeLoot.containsKey(item) && beforeLoot.get(item) < amount))
            {
                int beforeAmountAlreadyLooted = looted.getOrDefault(item.getName(), 0);
                int beforeGoldAlreadyLooted = gold.getOrDefault(item.getId(), 0);
                int afterGoldLooted = (item.getStack() * Pricing.lookupPrice(item.getId()).orElse(0));
                looted.put(item.getName(), amount + beforeAmountAlreadyLooted);
                gold.put(item.getId(), afterGoldLooted + beforeGoldAlreadyLooted);
                goldGained = getTotalGoldGained();
            }
        });
    }

    public void printSummary()
    {
        Logger.info("~<>~ Loot Summary ~<>~");
        Logger.info("~<>~ You have looted thus far ~<>~");
        looted.forEach((item, stack) -> Logger.info(String.format("~<>~ Item [%s] : Amount [%d] ~<>~", item, stack)));
        Logger.info(String.format("~<>~ For a total of [%d] unique items, equivalent to [%,d] gp ~<>~", looted.size(), goldGained));
        Logger.info("~<>~ Loot Summary End ~<>~");
    }

    public long getRunTime() {
        return System.currentTimeMillis() - startTime;
    }

    private int getTotalGoldGained()
    {
        return gold.values()
                .stream()
                .mapToInt(Integer::intValue)
                .sum();
    }

    private HashMap<InventoryItem, Integer> getMap()
    {
        var map = new HashMap<InventoryItem, Integer>();
        var inventory = Inventory.getAll();

        for (var item : inventory)
        {
            map.put(item, item.getStack());
        }

        return map;
    }
}
