package scripts.models;

import org.tribot.script.sdk.Skill;
import org.tribot.script.sdk.pricing.Pricing;
import scripts.models.listeners.InventoryListener;
import scripts.models.listeners.InventoryObserver;
import scripts.util.ScriptUtils;

import java.util.HashMap;

/**
 * @author Wastedbro - adopted by polymorphic
 */
public class GainTracker implements InventoryListener
{
    private static GainTracker tracker = null;

    private final long startTime;
    private final InventoryObserver inventoryObserver;
    private final HashMap<Integer, Integer> itemsGained;
    private final HashMap<Integer, Integer> goldGained;
    private final HashMap<Skill, Integer> startingStats;
    private final HashMap<Skill, Integer> startingStatsXp;

    private int totalGpGained;
    private boolean trackAllItems;
    private boolean trackGp;

    public static String XP_AND_LEVEL_STRING_FORMAT = "%,d (%,.2f/hr) (%d) (+%d)";

    private GainTracker()
    {
        inventoryObserver = new InventoryObserver();
        inventoryObserver.addListener(this);
        inventoryObserver.start();

        itemsGained = new HashMap<>();
        goldGained = new HashMap<>();
        startingStats = new HashMap<>();
        startingStatsXp = new HashMap<>();

        trackGp = true;

        for (Skill skill : Skill.values())
        {
            startingStats.put(skill, skill.getActualLevel());
            startingStatsXp.put(skill, skill.getXp());
        }

        startTime = System.currentTimeMillis();
    }

    public synchronized static GainTracker getInstance()
    {
        if (tracker == null)
            tracker = new GainTracker();
        return tracker;
    }

    @Override
    public void inventoryItemGained(int id, int count)
    {
        if (trackAllItems || itemsGained.containsKey(id))
        {
            itemsGained.put(id, itemsGained.get(id) + count);
            trackGp(id, count);
        }
    }

    @Override
    public void inventoryItemLost(int id, int count)
    {
        if (trackAllItems || itemsGained.containsKey(id))
        {
            itemsGained.put(id, itemsGained.get(id)-count);
            trackGp(id, -count);
        }
    }

    private void trackGp(int id, int count) {
        if (trackGp)
        {
            if (goldGained.containsKey(id))
            {
                goldGained.put(id, goldGained.get(id) + (count * Pricing.lookupPrice(id).orElse(0)));
            } else
            {
                goldGained.put(id, Pricing.lookupPrice(id).orElse(0));
            }
            totalGpGained = totalGpGained + (count * Pricing.lookupPrice(id).orElse(0));
        }
    }

    public void stop()
    {
        inventoryObserver.setShouldStop(true);
    }

    public long getTotalRuntime()
    {
        return System.currentTimeMillis() - startTime;
    }

    public int getLevelsGained(Skill skill)
    {
        return skill.getActualLevel() - startingStats.get(skill);
    }

    public int getXpGained(Skill skill)
    {
        return skill.getXp() - startingStatsXp.get(skill);
    }

    public String getSkillInfo(Skill skill)
    {
        return String.format
                (
                XP_AND_LEVEL_STRING_FORMAT,
                getXpGained(skill),
                ScriptUtils.getPerHour(getXpGained(skill), getTotalRuntime()),
                skill.getActualLevel(),
                getLevelsGained(skill)
                );
    }

    public int getTotalLevelsGained()
    {
        int gained = 0;

        for (Skill skill : Skill.values())
            gained += getLevelsGained(skill);

        return gained;
    }

    public int getTotalXpGained()
    {
        int gained = 0;

        for (Skill skill : Skill.values())
            gained += getXpGained(skill);

        return gained;
    }

    public void registerItemTrackers(int... itemIds)
    {
        for (int id : itemIds)
            itemsGained.put(id, 0);
    }

    public void deregisterItemTrackers(int... itemIds)
    {
        for (int id : itemIds)
            itemsGained.remove(id);
    }

    public int getItemsGained(int... itemIds)
    {
        int gained = 0;

        for (int id : itemIds)
            if (itemsGained.containsKey(id))
                gained += itemsGained.get(id);

        return gained;
    }

    public int getItemGpGained(int... itemIds)
    {
        int gained = 0;

        for (int id : itemIds)
            if (goldGained.containsKey(id))
                gained += goldGained.get(id);

        return gained;
    }

    public int getTotalGpGained() {
        return totalGpGained;
    }

    public boolean isTrackAllItems() {
        return trackAllItems;
    }

    public void setTrackAllItems(boolean shouldTrackAllItems)
    {
        this.trackAllItems = shouldTrackAllItems;
    }

    public boolean isTrackGp() {
        return trackGp;
    }

    public void setTrackGp(boolean trackGp) {
        this.trackGp = trackGp;
    }
}
