package scripts.models.settings;

import com.allatori.annotations.DoNotRename;
import lombok.*;
import scripts.antiban.AFKMicroSleep;

import java.io.Serializable;

@DoNotRename
@Data
@Builder
public class BasicScriptSettings implements Serializable {
    @DoNotRename
    @NonNull
    @Builder.Default
    private final AFKMicroSleep microSleep = AFKMicroSleep.Preset.PRESET_ONE.getPreset();

    @DoNotRename
    private final int playerSearchRadius, playerCountToHop;

    @DoNotRename
    private final boolean worldHopWhenPlayerInRadius;

    @DoNotRename
    private final boolean disablePaint;

    @DoNotRename
    @Builder.Default
    private final boolean enableShiftClickDrop = true;
}
