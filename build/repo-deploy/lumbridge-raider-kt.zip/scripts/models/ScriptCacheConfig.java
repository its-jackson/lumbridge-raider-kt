package scripts.models;

import com.allatori.annotations.DoNotRename;
import lombok.Builder;
import lombok.Data;
import lombok.NonNull;
import scripts.data.interactables.InteractableEntityEquipment;
import scripts.data.teleport.TeleportMethod;
import scripts.models.stopconditions.StopCondition;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@DoNotRename
@Data
@Builder
public class ScriptCacheConfig implements Serializable {
    @Builder.Default
    @NonNull
    @DoNotRename
    private StopCondition stopCondition = StopCondition.createInfiniteTimeCondition();

    @Builder.Default
    @NonNull
    @DoNotRename
    private List<InteractableEntityEquipment> equipmentList = new ArrayList<>();

    @Builder.Default
    @NonNull
    @DoNotRename
    private TeleportMethod primaryTeleportMethod = TeleportMethod.DEFAULT, grandExchangeTeleportMethod = TeleportMethod.DEFAULT;

    @DoNotRename
    private int foodID, foodMin, foodMax, foodAmtRestock;

    @DoNotRename
    private int staminaMin, staminaMax, staminaAmtRestock;
}
