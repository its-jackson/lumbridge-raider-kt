package scripts.models;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.tribot.script.sdk.interfaces.Positionable;
import org.tribot.script.sdk.query.Query;
import org.tribot.script.sdk.types.*;

import java.util.*;
import java.util.stream.Collectors;

public class Firemaking implements Iterable<Positionable> {
    private final Area firemakingArea;
    private final LinkedList<Positionable> lane;

    public Firemaking(Positionable startingPosition, int radius) {
        this.firemakingArea = Area.fromRadius((WorldTile) startingPosition, radius);
        this.lane = generateLane();
    }

    /**
     * Filters the positionable such that it's burnable, a burnable positionable is walkable,
     * has no scene flags, and no such game object is currently on it.
     *
     * @param positionable The positionable to be filtered
     * @return True if the positionable is burnable, otherwise false.
     */
    public boolean isTileBurnable(Positionable positionable) {
        return Query.tiles()
                .tileEquals(positionable)
                .filter(tile -> tile.isWalkable() && tile.getSceneSettings().isEmpty())
                .filter(tile -> !Query.gameObjects()
                                .tileEquals(tile)
                                .isInteractive()
                                .isAny())
                .isAny();
    }

    /**
     * Filters the tiles within the firemakingArea such that they are all burnable.
     *
     * @return The list of positionables that are burnable within an appropriate distance.
     */
    public List<Positionable> findBurnableTiles() {
        return Query.tiles()
                .inArea(firemakingArea)
                .filter(this::isTileBurnable)
                .maxPathDistance(15)
                .sortedByDistance()
                .stream()
                .map(LocalTile::toWorldTile)
                .collect(Collectors.toList());
    }

    /**
     * Get a firemaking lane with the most burnable tiles with respect to the valid tiles found.
     *
     * @return The generated firemaking lane, or an empty linked list if no lane generated.
     */
    public LinkedList<Positionable> generateLane() {
        List<Positionable> validTiles = findBurnableTiles();
        HashMap<Integer, LinkedList<Positionable>> lanes = new HashMap<>();
        int laneLength = 0;
        for (Positionable validTile : validTiles) {
            LocalTile neighbor = validTile.getTile().toLocalTile().getNeighbor(LocalTile.Direction.WEST);
            LinkedList<Positionable> lane = new LinkedList<>();
            while (isTileBurnable(neighbor)) {
                lane.add(neighbor.toWorldTile());
                neighbor = neighbor.getNeighbor(LocalTile.Direction.WEST);
                ++laneLength;
            }
            lanes.put(laneLength, lane);
            laneLength = 0;
        }
        int max = -1;
        Set<Integer> keys = lanes.keySet();
        for (Integer key : keys) {
            if (key > max) {
                max = key;
            }
        }
        if (max == -1) {
            return new LinkedList<>();
        } else {
            return lanes.get(max);
        }
    }

    @NotNull
    @Override
    public Iterator<Positionable> iterator() {
        return new LaneIterator(lane);
    }

    private static class LaneIterator implements Iterator<Positionable> {
        private final LinkedList<Positionable> lane;
        private int index;

        public LaneIterator(LinkedList<Positionable> lane) {
            this.lane = lane;
            this.index = 0;
        }

        @Override
        public boolean hasNext() {
            return index < lane.size();
        }

        @Nullable
        @Override
        public Positionable next() {
            return !hasNext() ? null : lane.get(index++); // return null - end of lane
        }
    }
}
