package scripts.models;

import org.tribot.script.sdk.query.Query;

public class Combiner {
    /**
     * @param a      The first item's id
     * @param b      The second item's id
     * @param method The method 0 equals a-b, 1 equals b-a.
     * @return True if the first item was used on the second time, false otherwise.
     */
    public static boolean combine(int a, int b, int method) {
        switch (method) {
            case 0:
                return useItemOnItem(a, b);
            case 1:
                return useItemOnItem(b, a);
            default:
                return false;
        }
    }

    /**
     * @param a      The first item's id
     * @param b      The second item's id
     * @param method The method 0 equals a-b, 1 equals b-a.
     * @return True if the first item was used on the second time, false otherwise.
     */
    public static boolean combineClosestToMouse(int a, int b, int method) {
        switch (method) {
            case 0:
                return useItemOnItemClosestToMouse(a, b);
            case 1:
                return useItemOnItemClosestToMouse(b, a);
            default:
                return false;
        }
    }

    /**
     * @param a      The first item's id
     * @param b      The second item's id
     * @param method The method 0 equals a-b, 1 equals b-a.
     * @return True if the first item was used on the second time, false otherwise.
     */
    public static boolean combineRandom(int a, int b, int method) {
        switch (method) {
            case 0:
                return useItemOnItemRandom(a, b);
            case 1:
                return useItemOnItemRandom(b, a);
            default:
                return false;
        }
    }


    private static boolean useItemOnItem(int a, int b) {
        return Query.inventory()
                .idEquals(a)
                .findFirst()
                .map(combinerItem -> combinerItem.ensureSelected() && Query.inventory()
                        .idEquals(b)
                        .findFirst()
                        .map(combinerItem::useOn)
                        .orElse(false)
                )
                .orElse(false);
    }

    private static boolean useItemOnItemClosestToMouse(int a, int b) {
        return Query.inventory()
                .idEquals(a)
                .findClosestToMouse()
                .map(combinerItem -> combinerItem.ensureSelected() && Query.inventory()
                        .idEquals(b)
                        .findClosestToMouse()
                        .map(combinerItem::useOn)
                        .orElse(false)
                )
                .orElse(false);
    }

    private static boolean useItemOnItemRandom(int a, int b) {
        return Query.inventory()
                .idEquals(a)
                .findRandom()
                .map(combinerItem -> combinerItem.ensureSelected() && Query.inventory()
                        .idEquals(b)
                        .findRandom()
                        .map(combinerItem::useOn)
                        .orElse(false)
                )
                .orElse(false);
    }

}