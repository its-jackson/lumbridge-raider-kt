package scripts.models;

import org.tribot.script.sdk.Log;

public class Logger {
    private static final String LOGGER_PREFIX = "PolyScript";

    public static void info(CharSequence debug) {
        Log.info(String.format("%s %s", getPrefix(), debug));
    }

    public static void debug(CharSequence debug) {
        Log.debug(String.format("%s %s", getPrefix(), debug));
    }

    public static void warn(CharSequence debug) {
        Log.warn(String.format("%s %s", getPrefix(), debug));
    }

    public static void trace(CharSequence debug) {
        Log.trace(String.format("%s %s", getPrefix(), debug));
    }

    public static void error(CharSequence debug) {
        Log.error(String.format("%s %s", getPrefix(), debug));
    }

    public static void error(CharSequence debug, Throwable throwable) {
        Log.error(String.format("%s %s %s", getPrefix(), debug, throwable));
    }

    private static String getPrefix() {
        return String.format("[%s]", LOGGER_PREFIX);
    }
}
