package scripts.models;

import org.tribot.script.sdk.interfaces.Item;
import org.tribot.script.sdk.query.Query;
import org.tribot.script.sdk.types.EquipmentItem;
import org.tribot.script.sdk.types.InventoryItem;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class ChargedItem {
    private static final Predicate<Item> CHARGED_ITEM_PREDICATE = item -> isChargedItem(item.getName());
    private static final Predicate<InventoryItem> CHARGED_INV_ITEM_PREDICATE = inventoryItem -> isChargedItem(inventoryItem.getName());
    private static final Predicate<EquipmentItem> CHARGED_EQUIP_ITEM_PREDICATE = equipmentItem -> isChargedItem(equipmentItem.getName());

    public static boolean hasInBank(String name) {
        return hasInBank(name, 1);
    }

    public static boolean hasInBank(String name, int minCharge) {
        return findInBank().stream()
                .anyMatch(item -> isCorrectCharge(name, item, minCharge));
    }

    public static boolean has(String name) {
        return has(name, 1);
    }

    public static boolean has(String name, int minCharge) {
        return findOnPlayer().stream()
                .anyMatch(item -> isCorrectCharge(name, item, minCharge));
    }

    public static List<Item> findInBank() {
        return Query.bank()
                .filter(CHARGED_ITEM_PREDICATE)
                .toList();
    }

    public static List<Item> findOnPlayer() {
        var items = new ArrayList<Item>();

        var inventoryItems = Query.inventory()
                .filter(CHARGED_INV_ITEM_PREDICATE)
                .toList();

        var equipmentItems = Query.equipment()
                .filter(CHARGED_EQUIP_ITEM_PREDICATE)
                .toList();

        items.addAll(inventoryItems);
        items.addAll(equipmentItems);

        return items;
    }

    private static boolean isChargedItem(String name) {
        return name.contains("(") && name.contains(")");
    }

    private static boolean isCorrectCharge(String name, Item item, int minCharge) {
        var itemName = item.getName();
        if (!itemName.contains(name))
            return false;
        int index = itemName.lastIndexOf("(");
        int index2 = itemName.lastIndexOf(")");
        if (!(index2 - index == 2))
            return false;
        String s = itemName.substring(index + 1, index2);
        if (s.equalsIgnoreCase("i"))
            return true;
        if (!s.matches("\\d"))
            return false;
        int currentCharge = Integer.parseInt(s);
        return currentCharge >= minCharge;
    }
}
