package scripts.models;

import dax.api_lib.DaxWalker;
import dax.walker.DaxWalkerEngine;
import dax.walker.utils.path.DaxPathFinder;
import lombok.val;
import org.tribot.api2007.types.RSTile;
import org.tribot.script.sdk.types.WorldTile;

import java.util.List;
import java.util.stream.Collectors;

public class LocalDaxWalkerEngine {
    private static LocalDaxWalkerEngine instance;

    private final DaxWalkerEngine engine;

    private LocalDaxWalkerEngine() {
        engine = new DaxWalkerEngine();
    }

    public static LocalDaxWalkerEngine getInstance() {
        if (instance == null)
            instance = new LocalDaxWalkerEngine();
        return instance;
    }

    public boolean walkPath(List<WorldTile> path) {
        val updated = path.stream()
                .map(worldTile -> new RSTile(worldTile.getX(), worldTile.getY(), worldTile.getPlane()))
                .collect(Collectors.toList());

        return engine.walkPath(updated);
    }
}
