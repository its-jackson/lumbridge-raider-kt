package scripts.models.tasks;

import scripts.data.interactables.InteractableEntityItemStats;
import scripts.enumerations.InventoryDisposal;
import scripts.models.stopconditions.StopCondition;

public interface TaskBuildable<SELF extends TaskBuildable<SELF, TTarget>, TTarget extends Task> {

    SELF resource(InteractableEntityItemStats interactableEntity);

    SELF stopCondition(StopCondition stopCondition);

    SELF inventoryDisposal(InventoryDisposal inventoryDisposal);

    TTarget build();
}
