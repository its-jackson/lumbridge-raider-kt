package scripts.models.tasks.generic;

import lombok.Data;

@Data
public final class ItemError
{
    private final String name;
    private final int amount, required;
}
