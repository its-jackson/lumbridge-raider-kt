package scripts.models.tasks.generic;

import lombok.Builder;
import lombok.Singular;
import org.jetbrains.annotations.NotNull;
import org.tribot.script.sdk.Bank;
import org.tribot.script.sdk.Inventory;
import org.tribot.script.sdk.cache.BankCache;
import org.tribot.script.sdk.interfaces.Stackable;
import org.tribot.script.sdk.query.Query;
import scripts.data.interactables.InteractableEntityItem;
import scripts.util.WaitingUtils;

import java.util.List;
import java.util.Optional;

@Builder
public class RestockInventoryTask {
    @Singular
    @NotNull
    private final List<InteractableEntityItem> items;

    public boolean isSatisfied() {
        return !isItemStackLow();
    }

    public Optional<ItemError> execute() {
        return Optional.of(items)
                .stream()
                .flatMap(List::stream)
                .filter(item -> !(getItemStack(item) >= getRequiredAmount(item)))
                .findFirst()
                .map(item -> new ItemError(item.getName(), getItemStack(item), getRequiredAmount(item)))
                .or(() -> {
                    Optional.of(items)
                            .stream()
                            .flatMap(List::stream)
                            .filter(this::isDepleted)
                            .forEach(item -> {
                                int qty = item.getQuantity() - Inventory.getCount(item.getName());
                                int count = qty + Inventory.getCount(item.getName());
                                if (!WaitingUtils.waitUntil(() -> Bank.withdraw(item.getName(), qty)))
                                    return;
                                WaitingUtils.waitUntil(3000, () -> Inventory.getCount(item.getName()) == count);
                                WaitingUtils.smallWait();
                                BankCache.update();
                            });
                    return Optional.empty();
                });
    }

    private boolean isItemStackLow() {
        return Optional.of(items)
                .stream()
                .flatMap(List::stream)
                .anyMatch(this::isDepleted);
    }

    private boolean isDepleted(InteractableEntityItem item) {
        return Inventory.getCount(item.getName()) == 0 || Inventory.getCount(item.getName()) <= (item.getQuantity() / 6);
    }

    private int getRequiredAmount(InteractableEntityItem item) {
        return item.getQuantity() - Inventory.getCount(item.getName());
    }

    private int getItemStack(InteractableEntityItem item) {
        return Query.bank()
                .nameEquals(item.getName())
                .findFirst()
                .map(Stackable::getStack)
                .orElse(0);
    }
}
