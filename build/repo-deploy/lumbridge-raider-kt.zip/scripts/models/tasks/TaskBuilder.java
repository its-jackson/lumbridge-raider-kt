package scripts.models.tasks;

import scripts.data.interactables.InteractableEntityItemStats;
import scripts.enumerations.InventoryDisposal;
import scripts.models.stopconditions.StopCondition;

public abstract class TaskBuilder<SELF extends TaskBuildable<SELF, TTarget>, TTarget extends Task>
        implements TaskBuildable<SELF, TTarget> {

    protected InteractableEntityItemStats interactableEntity;
    protected StopCondition stopCondition;
    protected InventoryDisposal inventoryDisposal;

    @Override
    public SELF resource(InteractableEntityItemStats interactableEntity) {
        this.interactableEntity = interactableEntity;
        return self();
    }

    @Override
    public SELF stopCondition(StopCondition stopCondition) {
        this.stopCondition = stopCondition;
        return self();
    }

    @Override
    public SELF inventoryDisposal(InventoryDisposal inventoryDisposal) {
        this.inventoryDisposal = inventoryDisposal;
        return self();
    }

    @Override
    public TTarget build() {
        return internalBuild();
    }

    protected abstract TTarget internalBuild();

    @SuppressWarnings("unchecked")
    private SELF self() {
        return (SELF) this;
    }
}
