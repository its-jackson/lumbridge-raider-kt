package scripts.models.tasks;

import com.allatori.annotations.DoNotRename;
import lombok.NonNull;
import org.jetbrains.annotations.NotNull;
import scripts.enumerations.InventoryDisposal;
import scripts.models.stopconditions.StopCondition;

import java.util.Optional;

@DoNotRename
public abstract class Task {
    @DoNotRename
    @NonNull
    private final StopCondition condition;
    @DoNotRename
    @NonNull
    private final InventoryDisposal disposal;

    public Task(@NonNull StopCondition condition, @NonNull InventoryDisposal disposal) {
        this.condition = condition;
        this.disposal = disposal;
    }

    public abstract boolean isTaskSatisfied();

    @NotNull
    public abstract Optional<TaskError> ensureSatisfied();

    @NotNull
    public StopCondition getCondition() {
        return condition;
    }

    @NotNull
    public InventoryDisposal getDisposal() {
        return disposal;
    }
}
