package scripts.models.tasks;

public enum TaskError {

    MEMBERSHIP_ERROR(),
    SKILL_LEVEL_ERROR()

}
