package scripts.models.stopconditions;

public class ResourceMadeSatisfiedCondition extends StopCondition {

    private int goal, currentCount;

    @Override
    public boolean isConditionSatisfied() {
        return currentCount >= goal;
    }

    public ResourceMadeSatisfiedCondition(int goal) {
        this.goal = goal;
    }

    public int getGoal() {
        return goal;
    }

    public void setGoal(int goal) {
        this.goal = goal;
    }

    public int getCurrentCount() {
        return currentCount;
    }

    public void setCurrentCount(int currentCount) {
        this.currentCount = currentCount;
    }

    public static void changeCurrentCount(StopCondition con, int count) {
        if (con instanceof ResourceMadeSatisfiedCondition) {
            final ResourceMadeSatisfiedCondition condition = (ResourceMadeSatisfiedCondition) con;
            condition.setCurrentCount(count + condition.getCurrentCount());
        }
    }

    @Override
    public String toString() {
        return "until resource made >= " + goal;
    }
}
