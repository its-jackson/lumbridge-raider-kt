package scripts.models.stopconditions;

public class ResourceGatheredSatisfiedCondition extends StopCondition {

    private int currentResourceCount, resourceGatheredGoal;

    public ResourceGatheredSatisfiedCondition(int resourceGatheredGoal) {
        this.resourceGatheredGoal = resourceGatheredGoal;
    }

    public void incrementCurrentResourceCount() {
        this.currentResourceCount++;
    }

    public int getCurrentResourceCount() {
        return currentResourceCount;
    }

    public void setCurrentResourceCount(int currentResourceCount) {
        this.currentResourceCount = currentResourceCount;
    }

    public int getResourceGatheredGoal() {
        return resourceGatheredGoal;
    }

    public void setResourceGatheredGoal(int resourceGatheredGoal) {
        this.resourceGatheredGoal = resourceGatheredGoal;
    }

    @Override
    public boolean isConditionSatisfied() {
        return this.currentResourceCount >= this.resourceGatheredGoal;
    }

    @Override
    public String toString() {
        return "until resource count >= " + resourceGatheredGoal;
    }
}
