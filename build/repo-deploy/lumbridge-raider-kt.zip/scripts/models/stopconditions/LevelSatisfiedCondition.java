package scripts.models.stopconditions;

import org.jetbrains.annotations.NotNull;
import org.tribot.script.sdk.Skill;

public class LevelSatisfiedCondition extends StopCondition {
    @NotNull
    private final Skill skill;
    private final int levelGoal;

    public LevelSatisfiedCondition(@NotNull Skill skill, int levelGoal) {
        this.skill = skill;
        this.levelGoal = levelGoal;
    }

    @NotNull
    public Skill getSkill() {
        return skill;
    }

    public int getLevelGoal() {
        return levelGoal;
    }

    @Override
    public boolean isConditionSatisfied() {
        return skill.getActualLevel() >= this.levelGoal;
    }

    @Override
    public String toString() {
        return "until level >= " + levelGoal;
    }
}
