package scripts.models.stopconditions;

import org.tribot.script.sdk.Skill;

public abstract class StopCondition {

    public abstract boolean isConditionSatisfied();

    public enum Conditions {
        LEVEL_SATISFIED("Level"),
        TIME_SATISFIED("Time (seconds)"),
        RESOURCE_GATHERED("Resource gathered"),
        GOLD_GATHERED("Gold gathered"),
        EXPERIENCE_GATHERED("EXP gathered"),
        RESOURCE_MADE("Resource made");

        final String condition;

        Conditions(String condition) {
            this.condition = condition;
        }

        public String getCondition() {
            return condition;
        }

        @Override
        public String toString() {
            return condition;
        }
    }

    public static StopCondition createSkillLevelCondition(Skill skill, int level) {
        return new LevelSatisfiedCondition(skill, level);
    }

    public static StopCondition createSkillLevelCondition(Skill skill, String level) {
        int g = 0;

        try {
            g = Integer.parseInt(level);
        }
        catch (NumberFormatException e) {
            e.printStackTrace();
        }

        return createSkillLevelCondition(skill, g);
    }

    public static StopCondition createResourceGatheredCondition(int goal) {
        return new ResourceGatheredSatisfiedCondition(goal);
    }

    public static StopCondition createResourceGatheredCondition(String goal) {
        int g = 0;

        try {
            g = Integer.parseInt(goal);
        }
        catch (NumberFormatException e) {
            e.printStackTrace();
        }

        return createResourceGatheredCondition(g);
    }

    public static StopCondition createResourceMadeCondition(int goal) {
        return new ResourceMadeSatisfiedCondition(goal);
    }

    public static StopCondition createTimeConditionOfSeconds(long time) {
        return new TimeSatisfiedCondition(time);
    }

    public static StopCondition createTimeConditionOfSeconds(String time) {
        long t = 0;

        try {
            t = Long.parseLong(time);
        }
        catch (NumberFormatException e) {
            e.printStackTrace();
        }

        return createTimeConditionOfSeconds(t);
    }

    public static StopCondition createInfiniteTimeCondition() {
        return createTimeConditionOfSeconds(Integer.MAX_VALUE);
    }
}

