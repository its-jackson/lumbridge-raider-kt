package scripts.models.stopconditions;

import org.apache.commons.lang3.time.StopWatch;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class TimeSatisfiedCondition extends StopCondition {

    private final StopWatch watch;
    private final Duration duration;

    public TimeSatisfiedCondition(long timeInSeconds) {
        this.duration = Duration.ofSeconds(timeInSeconds);
        this.watch = new StopWatch();
    }

    @Override
    public boolean isConditionSatisfied() {
        if (this.watch.isStopped()) {
            this.watch.start();
        }

        return this.watch.getTime(TimeUnit.SECONDS) >= this.duration.getSeconds();
    }

    public StopWatch getWatch() {
        return watch;
    }

    @Override
    public String toString() {
        return "until time >= " + duration.getSeconds() + " seconds";
    }
}
