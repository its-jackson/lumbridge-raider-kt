package scripts.models;

import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.tribot.script.sdk.tasks.BankTask;
import org.tribot.script.sdk.tasks.BankTaskError;
import scripts.data.interactables.InteractableEntityEquipment;
import scripts.data.teleport.TeleportMethod;
import scripts.grandexchange.GrandExchangeTask;
import scripts.models.stopconditions.StopCondition;

import java.util.ArrayList;
import java.util.List;

public class ScriptCache {
    private static ScriptCache instance = null;

    @Getter
    private final long startTime;

    @Getter
    @NotNull
    private final BreakManager breakManager;
    @Getter
    @NotNull
    private final LootTracker lootTracker;
    @Getter
    @NotNull
    private final List<BankTaskError> bankTaskErrorList;

    @Getter
    @Setter
    @NotNull
    private List<InteractableEntityEquipment> equipmentList;

    @Getter
    @Setter
    @NotNull
    private StopCondition stopCondition;

    @Getter
    @Setter
    @NotNull
    private TeleportMethod primaryTeleportMethod, grandExchangeTeleportMethod;

    @Getter
    @Setter
    @Nullable
    private GrandExchangeTask grandExchangeTask;
    @Getter
    @Setter
    @Nullable
    private BankTask bankTask;

    @Getter
    private int foodID, foodMin, foodMax, foodAmtRestock;

    @Getter
    private int staminaMin, staminaMax, staminaAmtRestock;

    @Getter
    @Setter
    private boolean initialized;

    private ScriptCache() {
        this.startTime = System.currentTimeMillis();
        this.breakManager = new BreakManager();
        this.lootTracker = new LootTracker();
        this.bankTaskErrorList = new ArrayList<>();
        this.equipmentList = new ArrayList<>();
        this.stopCondition = StopCondition.createInfiniteTimeCondition();
        this.primaryTeleportMethod = TeleportMethod.DEFAULT;
        this.grandExchangeTeleportMethod = TeleportMethod.DEFAULT;
    }

    public synchronized static ScriptCache getInstance() {
        if (instance == null)
            instance = new ScriptCache();
        return instance;
    }

    public long getTotalRuntime() {
        return System.currentTimeMillis() - startTime;
    }

    public void configure(@NotNull ScriptCacheConfig config) {
        this.foodID = config.getFoodID();
        this.foodMin = config.getFoodMin();
        this.foodMax = config.getFoodMax();
        this.foodAmtRestock = config.getFoodAmtRestock();
        this.staminaMin = config.getStaminaMin();
        this.staminaMax = config.getStaminaMax();
        this.staminaAmtRestock = config.getStaminaAmtRestock();
        this.stopCondition = config.getStopCondition();
        this.primaryTeleportMethod = config.getPrimaryTeleportMethod();
        this.grandExchangeTeleportMethod = config.getGrandExchangeTeleportMethod();
        this.equipmentList = config.getEquipmentList();
    }
}
