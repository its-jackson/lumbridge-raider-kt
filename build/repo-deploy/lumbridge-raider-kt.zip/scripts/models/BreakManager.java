package scripts.models;

import lombok.*;
import org.jetbrains.annotations.NotNull;
import org.tribot.script.sdk.antiban.PlayerPreferences;
import org.tribot.script.sdk.input.Mouse;
import org.tribot.script.sdk.util.TribotRandom;
import scripts.antiban.AntibanExtension;
import scripts.util.LoginHandler;
import scripts.util.WaitingUtils;

import javax.annotation.Nullable;
import java.time.Instant;
import java.util.*;
import java.util.function.BooleanSupplier;

@ToString
@EqualsAndHashCode
public final class BreakManager {
    // todo change breaking times and frequencies, right now it doesn't seem to be accurate.
    private final double breakTimeMean = PlayerPreferences.preference(
            "scripts.models.BreakManager.breakTimeMean",
            g -> g.uniform(900.0, 10800.0) // 15 minutes / 3 hours
    );
    private final double breakTimeStd = PlayerPreferences.preference(
            "scripts.models.BreakManager.breakTimeStd",
            g -> g.uniform(46.0, 276.0)
    );
    private final double breakFrequencyMean = PlayerPreferences.preference(
            "scripts.models.BreakManager.breakFrequencyMean",
            g -> g.uniform(1800.0, 21600.0)
    );
    private final double breakFrequencyStd = PlayerPreferences.preference(
            "scripts.models.BreakManager.breakFrequencyStd",
            g -> g.uniform(136.0, 566.0)
    );

    @Getter
    @NotNull
    private final HashMap<Double, Integer> allBreakTimes = new HashMap<>();

    @Getter
    @NotNull
    private final HashMap<Double, Integer> allFrequencyTimes = new HashMap<>();

    @Nullable
    private Instant manageTimer;

    @Getter
    @Setter
    private double breakTime, breakFrequency;

    @Getter
    private double lastBreakTime, lastBreakFrequency;

    @Getter
    private int count;

    @Getter
    @Setter
    private boolean enableBreaking = false;

    public BreakManager() {
        generateRandomBreakTime();
        generateRandomBreakFrequency();
    }

    public BreakManager(double breakTime, double breakFrequency) {
        this.breakTime = breakTime;
        this.breakFrequency = breakFrequency;
    }

    /**
     * Takes over the script and takes a break according to the current times.
     *
     * @param interruptCondition To end the break earlier.
     * @return True if the full break was taken, false otherwise.
     */
    public boolean takeBreak(BooleanSupplier interruptCondition) {
        updateStatePreBreak();

        if (AntibanExtension.getQualitativeProbability("scripts.models.BreakManager.logOutGame"))
            LoginHandler.logout();

        if (AntibanExtension.getQualitativeProbability("scripts.models.BreakManager.mouseLeaveScreen"))
            Mouse.leaveScreen();

        val start = Instant.now().getEpochSecond();

        while (breakTime > (Instant.now().getEpochSecond() - start)) {
            if (interruptCondition.getAsBoolean())
                break;
            WaitingUtils.waitUniform(200, 400);
        }

        generateRandomBreakTime();
        generateRandomBreakFrequency();
        generateManageTimer();

        return breakTime <= (Instant.now().getEpochSecond() - start);
    }

    public boolean shouldTakeBreak() {
        if (!enableBreaking) return false;
        if (manageTimer == null) generateManageTimer();
        return manageTimer != null && breakFrequency < (Instant.now().getEpochSecond() - manageTimer.getEpochSecond());
    }

    public String getBreakTimeString() {
        val header = "Taking break";

        if (breakTime >= 60)
            return String.format(
                    "%s %.0f minute(s) and %.0f second(s)",
                    header,
                    breakTime / 60,
                    breakTime % 60
            );
        else
            return String.format(
                    "%s %.2f second(s)",
                    header,
                    breakTime
            );
    }

    public double getBreakTimeMean() {
        return getMean(allBreakTimes.keySet());
    }

    public double getFrequencyMean() {
        return getMean(allFrequencyTimes.keySet());
    }

    public double getBreakTimeSampleStd() {
        return getSampleStd(allBreakTimes.keySet());
    }

    public double getBreakTimeSampleVariance() {
        return Math.pow(getBreakTimeSampleStd(), 2);
    }

    private double getSampleStd(Collection<Double> data) {
        if (data.size() < 1)
            throw new IllegalArgumentException("data length must be greater than zero.");

        val sampleMean = getMean(data);
        val n = data.size();
        var sigma = 0.0;

        for (val d : data)
            sigma = sigma + Math.pow(d - sampleMean, 2);

        return Math.sqrt(sigma / (n - 1));
    }

    private double getSampleVariance(Collection<Double> data) {
        val std = getSampleStd(data);
        return Math.pow(std, 2);
    }

    private double getMean(Collection<Double> data) {
        return data.stream()
                .mapToDouble(Double::doubleValue)
                .average()
                .orElse(0.0);
    }

    private double getNewBreakTime() {
        return TribotRandom.normal(breakTimeMean, breakTimeStd);
    }

    private double getNewBreakFrequency() {
        return TribotRandom.normal(breakFrequencyMean, breakFrequencyStd);
    }

    private void generateRandomBreakTime() {
        breakTime = getNewBreakTime();
    }

    private void generateRandomBreakFrequency() {
        breakFrequency = getNewBreakFrequency();
    }

    private void generateManageTimer() {
        manageTimer = Instant.now();
    }

    private void updateStatePreBreak() {
        count++;
        allBreakTimes.put(breakTime, allBreakTimes.getOrDefault(breakTime, 0) + 1);
        allFrequencyTimes.put(breakFrequency, allFrequencyTimes.getOrDefault(breakFrequency, 0) + 1);
        lastBreakTime = breakTime;
        lastBreakFrequency = breakFrequency;
    }
}
