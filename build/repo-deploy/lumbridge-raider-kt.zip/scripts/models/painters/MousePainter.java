package scripts.models.painters;

import org.tribot.script.sdk.painting.MousePaint;

import java.awt.*;

public class MousePainter implements MousePaint {

    @Override
    public void paintMouse(Graphics g, Point mousePos, Point dragPos) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHints(new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON));
        g2d.setColor(Color.white);
        g2d.setStroke(new BasicStroke(2));
        g2d.drawOval(mousePos.x - 4, mousePos.y - 2, 8, 8);
    }

}
