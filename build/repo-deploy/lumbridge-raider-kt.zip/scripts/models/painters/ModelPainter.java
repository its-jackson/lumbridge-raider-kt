package scripts.models.painters;

import org.tribot.script.sdk.interfaces.Modellable;
import org.tribot.script.sdk.types.Model;

import java.awt.*;
import java.util.function.Consumer;

public class ModelPainter implements Consumer<Graphics2D> {
    private final RenderingHints antialiasing  =
            new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);;
    private final Color color;
    private Shape shape;
    private Modellable model;

    public ModelPainter(Color color, Shape shape) {
        this.color = color;
        this.shape = shape;
    }

    public ModelPainter(Color color, Modellable model) {
        this.color = color;
        this.model = model;
    }

    /**
     * Performs this operation on the given argument.
     *
     * @param graphics2D the input argument
     */
    @Override
    public void accept(Graphics2D graphics2D) {
        if (model != null) {
            model.getModel().flatMap(Model::getBounds).ifPresent(polygon -> {
                graphics2D.setRenderingHints(antialiasing);
                graphics2D.setColor(color);
                graphics2D.draw(polygon);
            });
        }
        if (shape != null) {
            graphics2D.setRenderingHints(antialiasing);
            graphics2D.setColor(color);
            graphics2D.draw(shape);
        }
    }
}
