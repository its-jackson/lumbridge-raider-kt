package scripts.models.painters;

import org.tribot.script.sdk.interfaces.Positionable;
import org.tribot.script.sdk.types.WorldTile;

import java.awt.*;
import java.util.function.Consumer;

public class PositionablePainter implements Consumer<Graphics2D> {
    private final RenderingHints antialiasing;
    private final Color color;
    private final Positionable positionable;
    private final int stroke;

    public PositionablePainter(Color color, Positionable positionable, int stroke) {
        this.antialiasing = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        this.color = color;
        this.positionable = positionable;
        this.stroke = stroke;
    }

    /**
     * Performs this operation on the given argument.
     *
     * @param graphics2D the input argument
     */
    @Override
    public void accept(Graphics2D graphics2D) {
        WorldTile tile = positionable.getTile();
        tile.getBounds().ifPresent(polygon -> {
            if (!(tile.isVisible() && tile.isRendered()))
                return;
            graphics2D.setRenderingHints(antialiasing);
            graphics2D.setColor(color);
            graphics2D.setStroke(new BasicStroke(stroke));
            graphics2D.draw(polygon);
        });
    }
}
