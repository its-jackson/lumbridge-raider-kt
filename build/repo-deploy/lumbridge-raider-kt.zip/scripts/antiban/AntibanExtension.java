package scripts.antiban;

import lombok.Getter;
import org.tribot.script.sdk.antiban.Antiban;
import org.tribot.script.sdk.antiban.PlayerPreferences;
import org.tribot.script.sdk.util.TribotRandom;

import java.util.Random;

public final class AntibanExtension extends Antiban {
    private static ExtensionInstance extensionInstance = null;

    private AntibanExtension() {}

    public static double getCurrentEatPercent() {
        return getExtensionInstance().getCurrentEatPercent();
    }

    public static void generateEatPercent() {
        getExtensionInstance().generateEatPercent();
    }

    public static double getCurrentDrinkStaminaPercent() {
        return getExtensionInstance().getCurrentDrinkStaminaPercent();
    }

    public static void generateDrinkStaminaPercent() {
        getExtensionInstance().generateDrinkStaminaPercent();
    }

    public static boolean getQualitativeProbability(String key) {
        return getExtensionInstance().qualitativeProbability(key);
    }

    private synchronized static ExtensionInstance getExtensionInstance() {
        if (extensionInstance == null)
            extensionInstance = new ExtensionInstance();
        return extensionInstance;
    }

    private static class ExtensionInstance {
        private final double eatPercentMean = PlayerPreferences.preference(
                "scripts.antiban.AntibanExtension.ExtensionInstance.eatPercentMean",
                g -> g.uniform(50, 60.0)
        );
        private final double eatPercentStd = PlayerPreferences.preference(
                "scripts.antiban.AntibanExtension.ExtensionInstance.eatPercentStd",
                g -> g.uniform(1.0, 3.0)
        );

        private final double drinkStaminaMean = PlayerPreferences.preference(
                "scripts.antiban.AntibanExtension.ExtensionInstance.drinkStaminaMean",
                g -> g.uniform(25.0, 45.0)
        );
        private final double drinkStaminaStd = PlayerPreferences.preference(
                "scripts.antiban.AntibanExtension.ExtensionInstance.drinkStaminaStd",
                g -> g.uniform(1.3, 3.3)
        );

        @Getter
        private double currentEatPercent;

        @Getter
        private double currentDrinkStaminaPercent;

        private ExtensionInstance() {
            generateEatPercent();
            generateDrinkStaminaPercent();
        }

        /**
         * possible outcomes
         *
         * 50 mean 3 std
         * - empirical rule: 41 low - 59 high
         *
         * 50 mean 1 std
         * - empirical rule: 47 low - 53 high
         *
         * 60 mean 3 std
         * - empirical rule: 51 low - 69 high
         *
         * 60 mean 1 std
         * - empirical rule: 57 low - 63 high
         *
         * @return The next eating percentage.
         */
        private double getEatAtPercent() {
            return TribotRandom.normal(eatPercentMean, eatPercentStd);
        }

        /**
         * @author Nullable
         * Call this and cache it somewhere and use that cached value to determine if you should eat
         * Once you eat, set the cache value to another invocation of this function.
         */
        public void generateEatPercent() {
            currentEatPercent = getEatAtPercent();
        }

        private double getDrinkStaminaAtPercent() {
            return TribotRandom.normal(drinkStaminaMean, drinkStaminaStd);
        }

        public void generateDrinkStaminaPercent() {
            currentDrinkStaminaPercent = getDrinkStaminaAtPercent();
        }

        /**
         * Four categories of player types:
         * 1) Never performs X
         * 2) Always performs X
         * 3) Sometimes performs X
         * 4) Usually performs X
         */
        public boolean qualitativeProbability(String key) {
            var changeChance = 0.0;

            double changeUserType = PlayerPreferences.preference(
                    key.concat(".changeUserType"),
                    generator -> generator.uniform(0.0, 1.0)
            );

            if (changeUserType <= 0.12) {
                // 12% of users will not change teams
                changeChance = 0.0;
            } else if (changeUserType <= 0.30) {
                // 18% of users will always change teams
                changeChance = 1.0;
            } else if (changeUserType <= 0.65) {
                // 35% of players will sometimes change teams (around 35% chance)
                changeChance = PlayerPreferences.preference(
                        key.concat(".changeUserTypeRare"),
                        generator -> generator.normal(0.005, 0.955, 0.35, 0.10)
                );
            } else {
                // 35% of players will usually change teams (around 65% chance)
                changeChance = PlayerPreferences.preference(
                        key.concat(".changeUserTypeRare"),
                        generator -> generator.normal(0.005, 0.955, 0.65, 0.12)
                );
            }

            return new Random().nextDouble() <= changeChance;
        }
    }
}

