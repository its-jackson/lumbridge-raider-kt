package scripts.antiban;

import com.allatori.annotations.DoNotRename;
import lombok.*;
import org.tribot.script.sdk.input.Mouse;
import org.tribot.script.sdk.util.TribotRandom;
import scripts.models.Logger;
import scripts.util.LoginHandler;
import scripts.util.ScriptUtils;
import scripts.util.WaitingUtils;

import java.util.function.BooleanSupplier;

/**
 * @author polymorphic
 * <p>
 * Functions in seconds.
 */
@DoNotRename
@Getter
@ToString
@EqualsAndHashCode
public class AFKMicroSleep {
    @DoNotRename
    private final double frequencyMean, frequencySD;
    @DoNotRename
    private final double sleepMean, sleepSD;
    @DoNotRename
    private final boolean mouseAlwaysLeaveGame;
    @DoNotRename
    private final boolean alwaysLogout;

    @DoNotRename
    private double randomFrequencyTime, randomSleepTime;
    @DoNotRename
    private long frequencyTimer;
    @DoNotRename
    private int count;

    @Builder
    public AFKMicroSleep(double frequencyMean, double frequencySD, double sleepMean, double sleepSD, boolean mouseAlwaysLeaveGame, boolean alwaysLogout) {
        this.frequencyMean = frequencyMean;
        this.frequencySD = frequencySD;
        this.sleepMean = sleepMean;
        this.sleepSD = sleepSD;
        this.mouseAlwaysLeaveGame = mouseAlwaysLeaveGame;
        this.alwaysLogout = alwaysLogout;
        generateRandomFrequencyTime();
        generateRandomSleepTime();
    }

    public void sleep(BooleanSupplier interruptCondition) {
        if (!shouldSleep())
            return;

        count++;

        if (alwaysLogout || (randomSleepTime > TribotRandom.normal(600, 44) && TribotRandom.normal(50, 15) > 64))
            LoginHandler.logout();

        if (mouseAlwaysLeaveGame || TribotRandom.normal(50, 15) < 46)
            Mouse.leaveScreen();

        Logger.info(getSleepTime());

        long sleepStartTime = currentTimeSeconds();

        while (randomSleepTime > (currentTimeSeconds() - sleepStartTime)) {
            if (interruptCondition.getAsBoolean())
                break;
            WaitingUtils.waitUniform(400, 600);
        }

        generateRandomFrequencyTime();
        generateRandomSleepTime();
        frequencyTimer = currentTimeSeconds();
    }

    public String getSleepTime() {
        String header = "Taking break:";

        if (randomSleepTime >= 60) {
            return String.format(
                    "%s %.0f minute(s) and %.0f second(s)",
                    header,
                    randomSleepTime / 60,
                    randomSleepTime % 60
            );
        } else {
            return String.format(
                    "%s %.2f second(s)",
                    header,
                    randomSleepTime
            );
        }
    }

    public boolean shouldSleep() {
        if (frequencyTimer == 0)
            frequencyTimer = currentTimeSeconds();

        return randomFrequencyTime < (currentTimeSeconds() - frequencyTimer);
    }

    private long currentTimeSeconds() {
        return (System.currentTimeMillis() / 1000);
    }

    private void generateRandomFrequencyTime() {
        randomFrequencyTime = ScriptUtils.randomSD(this.frequencyMean, this.frequencySD);
    }

    private void generateRandomSleepTime() {
        randomSleepTime = ScriptUtils.randomSD(this.sleepMean, this.sleepSD);
    }

    @Getter
    public enum Preset {
        PRESET_ONE(
                1200,
                200,
                400,
                66,
                false,
                false
        ),
        PRESET_TWO(
                60,
                10,
                100,
                30,
                false,
                false
        );

        private final AFKMicroSleep preset;

        Preset(double frequencyMean, double frequencySD, double sleepMean, double sleepSD, boolean mouse, boolean logout) {
            this.preset = new AFKMicroSleep(frequencyMean, frequencySD, sleepMean, sleepSD, mouse, logout);
        }
    }
}
