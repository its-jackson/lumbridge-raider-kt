package scripts.gui;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.tribot.script.sdk.Waiting;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unsafe operation")
public class GUIFX extends Application {
    private AbstractGUIController controller;

    private String css;

    private Stage stage;
    private Scene scene;

    private boolean isOpen = false;
    private boolean interruptEnd = false;
    private final String fxml;
    private final String title;
    private final List<Stage> children;

    private GUIFX(String fxml, String title) {
        this.fxml = fxml;
        this.title = title;
        this.children = new ArrayList<>();

        SwingUtilities.invokeLater(() -> {
            new JFXPanel(); // toolkit
            Platform.runLater(() -> {
                try {
                    final Stage stage = new Stage();
                    start(stage);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        });

        Waiting.waitUntil(7000, () -> stage != null);
    }

    private GUIFX(String fxml, String title, String css) {
        this(fxml, title);
        this.css = css;
    }

    public Scene getScene() {
        return this.scene;
    }

    public Stage getStage() {
        return this.stage;
    }

    /**
     * The main entry point for all JavaFX applications. The start method is called
     * after the init method has returned, and after the system is ready for the
     * application to begin running.
     * <p>
     * <p>
     * NOTE: This method is called on the JavaFX Application Thread.
     * </p>
     *
     * @param stage the primary stage for this application, onto which the application
     *              scene can be set. The primary stage will be embedded in the
     *              browser if the application was launched as an applet. Applications
     *              may create other stages, if needed, but they will not be primary
     *              stages and will not be embedded in the browser.
     */
    @Override
    public void start(Stage stage) throws Exception {
        if (fxml == null)
            return;

        this.stage = stage;

        stage.setTitle(this.title);

        stage.setAlwaysOnTop(true);

        Platform.setImplicitExit(false);

        FXMLLoader loader = new FXMLLoader();

        loader.setClassLoader(this.getClass().getClassLoader());

        Parent box = loader.load(new ByteArrayInputStream(fxml.getBytes()));

        controller = loader.getController();

        if (controller == null)
            return;

        controller.setGui(this);

        scene = new Scene(box);

        if (css != null) {
            scene.getStylesheets().add(css);
        }

        stage.setScene(scene);

        stage.setResizable(true);

        stage.setOnCloseRequest(event -> {
            interruptEnd = true;
            close();
        });
    }

    public <T extends AbstractGUIController> T getController() {
        return (T) this.controller;
    }

    public List<Stage> getChildren() {
        return children;
    }

    public void show() {
        if (stage == null)
            return;

        isOpen = true;

        Platform.runLater(() -> stage.show());
    }

    public void close() {
        if (stage == null)
            return;

        isOpen = false;

        Platform.runLater(() -> {
            // close all children windows
            if (!children.isEmpty()) {
                for (Stage child : children) {
                    if (child != null) child.close();
                }
            }

            stage.close();
        });
    }

    public boolean isOpen() {
        return isOpen;
    }

    public boolean isInterruptEnd() {
        return interruptEnd;
    }

    public void setInterruptEnd(boolean interruptEnd) {
        this.interruptEnd = interruptEnd;
    }

    private static Image getImage(String url) {
        try {
            return ImageIO.read(new URL(url));
        } catch (IOException e) {
            return null;
        }
    }

    public static GUIFX loadGUI(String resource, String title) {
        return new GUIFX(resource, title);
    }

    public static GUIFX loadGUI(String resource, String title, String css) {
        return new GUIFX(resource, title, css);
    }

    public static boolean handleGUI(GUIFX gui) {
        if (gui == null)
            return false;
        gui.show();
        while (gui.isOpen())
            Waiting.wait(500);
        return !gui.isInterruptEnd();
    }

    private class GUIThread extends Thread {
        private final GUIFX gui;

        public GUIThread(GUIFX gui) {
            this.gui = gui;
        }

        @Override
        public void run() {
            if (gui == null)
                return;
            gui.show();
            while (gui.isOpen()) {
                if (!gui.isInterruptEnd())
                    break;
                Waiting.wait(500);
            }
        }
    }
}
