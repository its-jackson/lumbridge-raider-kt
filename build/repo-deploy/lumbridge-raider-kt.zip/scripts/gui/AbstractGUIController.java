package scripts.gui;

import com.allatori.annotations.DoNotRename;
import javafx.fxml.Initializable;

@DoNotRename
public abstract class AbstractGUIController implements Initializable {
    @DoNotRename
    private GUIFX gui;

    public GUIFX getGui() {
        return gui;
    }

    public void setGui(GUIFX gui) {
        this.gui = gui;
    }
}
